// Close The Market — shared behaviour across all pages

// Mobile nav toggle
(function () {
  var btn = document.getElementById('menu-toggle');
  var menu = document.getElementById('mobile-menu');
  var iconOpen = document.getElementById('menu-icon-open');
  var iconClose = document.getElementById('menu-icon-close');
  if (!btn || !menu) return;
  function closeMenu() {
    menu.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
    iconOpen.classList.remove('hidden');
    iconClose.classList.add('hidden');
  }
  btn.addEventListener('click', function () {
    var isOpen = menu.classList.toggle('open');
    btn.setAttribute('aria-expanded', String(isOpen));
    iconOpen.classList.toggle('hidden', isOpen);
    iconClose.classList.toggle('hidden', !isOpen);
  });
  menu.querySelectorAll('a').forEach(function (link) { link.addEventListener('click', closeMenu); });
})();

// Scroll-reveal
(function () {
  var targets = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window)) {
    targets.forEach(function (el) { el.classList.add('is-visible'); });
    return;
  }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); io.unobserve(entry.target); }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
  targets.forEach(function (el) { io.observe(el); });
})();

// Sticky nav shadow
(function () {
  var header = document.querySelector('header');
  if (!header) return;
  function onScroll() { header.classList.toggle('scrolled', window.scrollY > 8); }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

// Join page: pre-fill from ?interest=...&role=... (set by links on other pages)
// and only show the niche / experience questions when they're relevant.
(function () {
  var interest = document.getElementById('interest');
  if (!interest) return;
  var niche = document.getElementById('role-interest');
  var nicheWrap = document.getElementById('niche-wrap');
  var expWrap = document.getElementById('experience-wrap');
  var params = new URLSearchParams(window.location.search);
  var i = params.get('interest');
  var role = params.get('role');
  if (i) Array.prototype.forEach.call(interest.options, function (o) { if (o.value === i) interest.value = i; });
  if (role) {
    if (!i) interest.value = 'pool';
    Array.prototype.forEach.call(niche.options, function (o) { if (o.value === role) niche.value = role; });
  }
  function sync() {
    var v = interest.value;
    nicheWrap.classList.toggle('hidden', v === 'follow' || v === 'training');
    expWrap.classList.toggle('hidden', v === 'business' || v === 'follow');
  }
  interest.addEventListener('change', sync);
  sync();
})();

// Instagram attribution: anyone who lands on /ig (or any page with ?src=...) is
// remembered for this browser tab, and every form they submit is tagged with it,
// e.g. source = "instagram / home-hero". Shows up in Netlify → Forms.
(function () {
  var src = null;
  try {
    var params = new URLSearchParams(window.location.search);
    var path = window.location.pathname.replace(/\.html$/, '').replace(/\/$/, '');
    if (path === '/ig') src = 'instagram';
    if (params.get('src')) src = params.get('src');
    if (src) sessionStorage.setItem('ctm_src', src);
    else src = sessionStorage.getItem('ctm_src');
  } catch (e) {}
  if (!src) return;
  document.querySelectorAll('input[name="source"]').forEach(function (el) {
    if (el.value.indexOf(src) !== 0) el.value = src + ' / ' + (el.value || 'unknown');
  });
})();

// Before/after flashcards: tap or press Enter/Space to flip.
document.querySelectorAll('.flipcard').forEach(function (card) {
  card.addEventListener('click', function () {
    var on = card.getAttribute('aria-pressed') !== 'true';
    card.setAttribute('aria-pressed', String(on));
  });
});
