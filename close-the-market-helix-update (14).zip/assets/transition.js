// Close The Market — helix page transition.
// Leaving a page: two dark panels close from the sides, and their gold edges
// twist into a spinning double helix. Arriving: the helix untwists back into
// two lines and the panels open on the new page.
(function () {
  'use strict';
  var root = document.documentElement;
  var KEY = 'ctm_t';
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce || !window.requestAnimationFrame || !document.createElement('canvas').getContext) {
    root.classList.remove('ctm-enter');
    return;
  }

  var BG = '#0a0907';
  var CLOSE_MS = 290, TWIST_MS = 290, TWIST_AT = CLOSE_MS, EXIT_MS = TWIST_AT + TWIST_MS; // leaving
  var HOLD_MS = 140, UNTWIST_MS = 240, OPEN_MS = 460;                               // arriving

  var canvas = null, ctx = null, W = 0, H = 0, raf = 0, mode = 'idle', t0 = 0, safety = 0;

  function clamp(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
  function easeInOut(p) { return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2; }
  function easeOut(p) { return 1 - Math.pow(1 - p, 3); }
  function easeIn(p) { return p * p * p; }

  function mount() {
    if (canvas) return;
    canvas = document.createElement('canvas');
    canvas.setAttribute('aria-hidden', 'true');
    canvas.style.cssText = 'position:fixed;left:0;top:0;width:100%;height:100%;z-index:2147483001;pointer-events:auto;display:block';
    document.body.appendChild(canvas);
    ctx = canvas.getContext('2d');
    size();
  }
  function unmount() {
    cancelAnimationFrame(raf); clearTimeout(safety);
    if (canvas && canvas.parentNode) canvas.parentNode.removeChild(canvas);
    canvas = ctx = null; mode = 'idle';
  }
  function size() {
    if (!canvas) return;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  window.addEventListener('resize', size);

  // cover: 0 = panels fully open, 1 = closed. twist: 0 = straight line, 1 = full helix.
  function draw(cover, twist) {
    ctx.clearRect(0, 0, W, H);
    var cx = W / 2, pw = cover * (cx + 1);
    ctx.fillStyle = BG;
    ctx.fillRect(0, 0, pw, H);
    ctx.fillRect(W - pw, 0, pw, H);

    if (cover < 1) {
      // gold leading edges of the two panels
      var a = clamp(cover * 5);
      edge(pw, a); edge(W - pw, a);
      return;
    }

    // soft gold haze behind the helix
    var amp = Math.max(34, Math.min(W * 0.085, 78));
    var g = ctx.createRadialGradient(cx, H / 2, 0, cx, H / 2, Math.max(H * 0.55, 320));
    g.addColorStop(0, 'rgba(212,175,55,' + (0.07 * twist).toFixed(3) + ')');
    g.addColorStop(1, 'rgba(212,175,55,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    var A = amp * twist, lambda = amp * 3.7, k = Math.PI * 2 / lambda;
    var phi = (Date.now() / 1000) * 2.6;            // wall-clock, so the spin carries on across pages
    var step = 5, y, th, s, z;

    strand(-1, false); strand(1, false);            // far side first
    if (twist > 0.02) {
      var gap = lambda / 8, off = ((phi / k) % gap + gap) % gap;
      for (y = -gap + off; y < H + gap; y += gap) {
        th = k * y - phi; s = Math.sin(th); z = Math.cos(th);
        var x1 = cx + A * s, x2 = cx - A * s;
        ctx.globalAlpha = (0.16 + 0.3 * Math.abs(s)) * twist;
        ctx.strokeStyle = '#d4af37'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(x1, y); ctx.lineTo(x2, y); ctx.stroke();
        dot(x1, y, z, twist); dot(x2, y, -z, twist);
      }
    }
    strand(-1, true); strand(1, true);              // near side on top
    ctx.globalAlpha = 1;

    function strand(sign, front) {
      for (var yy = 0; yy < H; yy += step) {
        var t1 = k * yy - phi, zz = sign * Math.cos(t1 + k * step / 2);
        if ((zz >= 0) !== front) continue;
        var d = (zz + 1) / 2;
        var xa = cx + sign * A * Math.sin(t1), xb = cx + sign * A * Math.sin(t1 + k * step);
        ctx.strokeStyle = '#d4af37'; ctx.lineCap = 'round';
        ctx.globalAlpha = 0.10 + 0.14 * d; ctx.lineWidth = 7 + 5 * d;       // glow
        ctx.beginPath(); ctx.moveTo(xa, yy); ctx.lineTo(xb, yy + step); ctx.stroke();
        ctx.strokeStyle = d > 0.6 ? '#e8c35a' : '#d4af37';
        ctx.globalAlpha = 0.34 + 0.66 * d; ctx.lineWidth = 1.4 + 1.6 * d;   // core
        ctx.beginPath(); ctx.moveTo(xa, yy); ctx.lineTo(xb, yy + step + 0.6); ctx.stroke();
      }
    }
    function dot(x, yy, zz, tw) {
      var d = (zz + 1) / 2;
      ctx.globalAlpha = (0.3 + 0.7 * d) * tw; ctx.fillStyle = d > 0.6 ? '#f1d98a' : '#d4af37';
      ctx.beginPath(); ctx.arc(x, yy, 1.6 + 2.4 * d, 0, 6.2832); ctx.fill();
    }
  }
  function edge(x, a) {
    ctx.globalAlpha = 0.16 * a; ctx.fillStyle = '#d4af37'; ctx.fillRect(x - 5, 0, 10, H);
    ctx.globalAlpha = a; ctx.fillStyle = '#e8c35a'; ctx.fillRect(x - 1, 0, 2, H);
    ctx.globalAlpha = 1;
  }

  // ---- leaving ----
  function leave(url) {
    try { sessionStorage.setItem(KEY, String(Date.now())); } catch (e) {}
    mount(); mode = 'leave'; t0 = performance.now();
    var gone = false;
    (function frame(now) {
      if (mode !== 'leave') return;
      var t = now - t0;
      draw(easeInOut(clamp(t / CLOSE_MS)), easeOut(clamp((t - TWIST_AT) / TWIST_MS)));
      if (t >= EXIT_MS && !gone) { gone = true; window.location.assign(url); }
      raf = requestAnimationFrame(frame);       // keep spinning until the next page takes over
    })(t0);
    clearTimeout(safety);
    safety = setTimeout(function () { if (mode === 'leave') arrive(); }, 5000); // navigation never happened
  }

  // ---- arriving ----
  function arrive() {
    mount(); mode = 'arrive'; t0 = performance.now();
    draw(1, 1);
    requestAnimationFrame(function () { root.classList.remove('ctm-enter'); });
    var rose = false;
    (function frame(now) {
      if (mode !== 'arrive') return;
      var t = now - t0 - HOLD_MS;
      var twist = 1 - easeIn(clamp(t / UNTWIST_MS));
      var open = easeInOut(clamp((t - UNTWIST_MS) / OPEN_MS));
      if (t > UNTWIST_MS && !rose) {
        rose = true; root.classList.add('ctm-arrive');
        setTimeout(function () { root.classList.remove('ctm-arrive'); }, 900);
      }
      draw(1 - open, twist);
      if (open >= 1) { unmount(); return; }
      raf = requestAnimationFrame(frame);
    })(t0);
  }

  // Start: are we arriving from a transition?
  var fresh = false;
  try {
    var stamp = +sessionStorage.getItem(KEY);
    fresh = !!stamp && Date.now() - stamp < 6000;
    sessionStorage.removeItem(KEY);
  } catch (e) {}
  if (fresh) arrive(); else root.classList.remove('ctm-enter');

  // Back/forward cache: the page was frozen mid-exit, so open it up again.
  window.addEventListener('pageshow', function (e) {
    if (e.persisted && canvas) { try { sessionStorage.removeItem(KEY); } catch (x) {} arrive(); }
  });

  // Intercept ordinary same-site link clicks.
  document.addEventListener('click', function (e) {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (mode !== 'idle') { return; }
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a || a.target && a.target !== '_self' || a.hasAttribute('download')) return;
    var raw = a.getAttribute('href');
    if (!raw || raw.charAt(0) === '#' || /^(mailto:|tel:|sms:|javascript:)/i.test(raw)) return;
    var url;
    try { url = new URL(a.href, window.location.href); } catch (x) { return; }
    if (url.origin !== window.location.origin) return;
    if (/\.(pdf|zip|png|jpe?g|svg|json)$/i.test(url.pathname) || url.pathname.indexOf('/files/') === 0) return;
    if (url.pathname === window.location.pathname && url.search === window.location.search) return; // same page / anchor
    e.preventDefault();
    leave(url.href);
  });
})();
