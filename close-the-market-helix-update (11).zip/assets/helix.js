// Close The Market — helix homepage.
// The page's sections sit on a 3D double helix. Scrolling travels along it:
// each section swings round to the front as the helix turns.
(function () {
  'use strict';
  var root = document.documentElement;
  var hx = document.getElementById('helix');
  if (!hx) return;

  var ok = root.classList.contains('hx-on') && window.requestAnimationFrame &&
    !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) &&
    (!window.CSS || !CSS.supports || CSS.supports('transform-style', 'preserve-3d'));
  if (!ok) { root.classList.remove('hx-on'); return; }

  var stage = hx.querySelector('.hx-stage');
  var canvas = hx.querySelector('.hx-canvas');
  var ctx = canvas.getContext('2d');
  var panels = Array.prototype.slice.call(hx.querySelectorAll('.hx-panel'));
  var inners = panels.map(function (p) { return p.querySelector('.hx-inner'); });
  var rail = hx.querySelector('.hx-rail');
  var hint = hx.querySelector('.hx-hint');
  var N = panels.length;

  var P = 1600;                 // perspective distance (matches the CSS)
  var TURN = Math.PI;           // helix turns half a revolution per section
  var W = 0, H = 0, cy = 0, R = 0, pitch = 0, stepH = 0, top = 0;
  var cur = 0, target = 0, running = false, active = -1;

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  // Rail buttons + snap anchors
  var buttons = [];
  panels.forEach(function (p, i) {
    var b = document.createElement('button');
    b.type = 'button';
    b.setAttribute('aria-label', 'Go to section ' + (i + 1) + ': ' + (p.getAttribute('data-title') || ''));
    var s = document.createElement('span'); s.textContent = p.getAttribute('data-title') || '';
    b.appendChild(s);
    b.addEventListener('click', function () { go(i); });
    rail.appendChild(b); buttons.push(b);
  });

  // Settling: when scrolling stops between two sections, carry on to the next one in
  // the direction of travel (one wheel notch or a short swipe moves one section).
  var rest = 0, auto = false, touching = false, lastY = window.pageYOffset, dir = 0, idle = 0;
  function go(i) {
    i = clamp(i, 0, N - 1); rest = i; auto = true;
    window.scrollTo({ top: Math.round(top + i * stepH), behavior: 'smooth' });
  }
  function settle() {
    if (touching) return;
    var y = window.pageYOffset, s = (y - top) / stepH;
    if (auto) { auto = false; rest = clamp(Math.round(s), 0, N - 1); }
    if (s < -0.02 || s > N - 1 + 0.02) return;            // above the helix or down in the footer
    var delta = s - rest;
    if (Math.abs(delta) < 0.012) return;
    var to = Math.abs(delta) < 0.05 ? rest : (dir > 0 ? Math.ceil(s) : Math.floor(s));
    go(to);
  }
  function onScroll() {
    var y = window.pageYOffset;
    if (y !== lastY) { if (!auto) dir = y > lastY ? 1 : -1; lastY = y; }
    clearTimeout(idle); idle = setTimeout(settle, auto ? 110 : 150);
    kick();
  }
  window.addEventListener('touchstart', function () { touching = true; auto = false; }, { passive: true });
  window.addEventListener('touchend', function () { touching = false; clearTimeout(idle); idle = setTimeout(settle, 160); }, { passive: true });
  window.addEventListener('wheel', function () { auto = false; }, { passive: true });

  function layout() {
    W = stage.clientWidth; H = window.innerHeight;
    var head = 64;
    cy = Math.round(head + (H - head) / 2 - (W < 820 ? 14 : 0));
    var pw = panels[0].offsetWidth;
    var reach = Math.min(pw / 2 + 84, W / 2 - 6);       // how far the strands swing out on screen
    R = reach * P / (P - reach);
    pitch = clamp(H * 0.62, 400, 760);
    stepH = Math.round(H * 0.8);
    hx.style.height = ((N - 1) * stepH + H) + 'px';
    stage.style.perspectiveOrigin = '50% ' + cy + 'px';
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    top = hx.getBoundingClientRect().top + window.pageYOffset;
    read(); cur = target; rest = clamp(Math.round((window.pageYOffset - top) / stepH), 0, N - 1); render();
  }

  // Scroll position -> place on the helix. Eased, so each section lingers at the front
  // and the turn between two sections happens quickly in the middle of the scroll.
  function read() {
    var s = clamp((window.pageYOffset - top) / stepH, 0, N - 1), i = Math.floor(s), x = s - i;
    target = i + (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
  }

  function render() {
    var i, d, a, c, p, vis;
    for (i = 0; i < N; i++) {
      p = panels[i]; d = i - cur; a = d * TURN; c = Math.cos(a);
      if (Math.abs(d) > 2.3) { if (p.style.visibility !== 'hidden') p.style.visibility = 'hidden'; continue; }
      p.style.visibility = 'visible';
      p.style.transform = 'translate(-50%,-50%) translate3d(0,' + (cy + d * pitch).toFixed(1) + 'px,' + (-R).toFixed(1) + 'px) rotateY(' + a.toFixed(4) + 'rad) translateZ(' + R.toFixed(1) + 'px)';
      if (c > 0) {                                   // facing us: real content
        p.style.opacity = (0.2 + 0.8 * c).toFixed(3);
        inners[i].style.opacity = clamp((c - 0.12) / 0.55, 0, 1).toFixed(3);
      } else {                                       // far side of the helix: a dim plate
        vis = clamp(2.3 - Math.abs(d), 0, 1);
        p.style.opacity = (0.2 * vis + 0.12 * vis * -c).toFixed(3);
        inners[i].style.opacity = '0';
      }
    }
    var now = Math.round(cur);
    if (now !== active) {
      active = now;
      panels.forEach(function (el, j) { el.classList.toggle('is-active', j === now); });
      buttons.forEach(function (b, j) { if (j === now) b.setAttribute('aria-current', 'true'); else b.removeAttribute('aria-current'); });
    }
    if (hint) hint.style.opacity = cur < 0.12 ? '1' : '0';
    drawHelix();
  }

  // Project a point on the helix. phase 0 = the strand the panels sit on, PI = its partner.
  function pt(u, phase) {
    var a = (u - cur) * TURN + phase, Z = -R + R * Math.cos(a), f = P / (P - Z);
    return [W / 2 + R * Math.sin(a) * f, cy + (u - cur) * pitch * f, Math.cos(a), f];
  }

  function drawHelix() {
    ctx.clearRect(0, 0, W, H);
    var g = ctx.createRadialGradient(W / 2, cy, 0, W / 2, cy, Math.max(W, H) * 0.6);
    g.addColorStop(0, 'rgba(212,175,55,0.11)'); g.addColorStop(1, 'rgba(212,175,55,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

    var u0 = cur - 2.6, u1 = cur + 2.6, du = 0.02, u, a, b, q, d, k;
    ctx.lineCap = 'round';

    function strands(front) {
      ctx.lineCap = 'butt';
      for (var s = 0; s < 2; s++) {
        var ph = s * Math.PI;
        for (u = u0; u < u1; u += du) {
          a = pt(u, ph); b = pt(u + du, ph);
          if ((a[2] >= 0) !== front) continue;
          if ((a[1] < -40 && b[1] < -40) || (a[1] > H + 40 && b[1] > H + 40)) continue;
          d = (a[2] + 1) / 2;
          ctx.strokeStyle = '#d4af37';
          ctx.globalAlpha = 0.035 + 0.05 * d; ctx.lineWidth = (26 + 22 * d) * a[3];      // wide halo
          ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
          ctx.globalAlpha = 0.13 + 0.2 * d; ctx.lineWidth = (10 + 9 * d) * a[3];          // glow
          ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
          ctx.strokeStyle = d > 0.55 ? '#f1d98a' : '#e0bb4a';
          ctx.globalAlpha = 0.5 + 0.5 * d; ctx.lineWidth = (2.6 + 3.6 * d) * a[3];        // core
          ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
        }
      }
    }

    strands(false);
    // rungs between the two strands, and a bright node where each section is attached
    var r0 = Math.ceil(u0 * 8) / 8, mx, my, fm, al;
    for (u = r0; u < u1; u += 1 / 8) {
      a = pt(u, 0); q = pt(u, Math.PI);
      if (a[1] < -20 && q[1] < -20 || a[1] > H + 20 && q[1] > H + 20) continue;
      mx = (a[0] + q[0]) / 2; my = (a[1] + q[1]) / 2; fm = (a[3] + q[3]) / 2;
      al = 0.3 + 0.3 * Math.abs(Math.sin((u - cur) * TURN));
      ctx.lineWidth = 2.2 * fm; ctx.lineCap = 'butt';
      ctx.globalAlpha = al; ctx.strokeStyle = '#d4af37';                 // one base
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(mx, my); ctx.stroke();
      ctx.globalAlpha = al * 0.8; ctx.strokeStyle = '#8f7a3a';           // its pair
      ctx.beginPath(); ctx.moveTo(mx, my); ctx.lineTo(q[0], q[1]); ctx.stroke();
      ctx.lineCap = 'round';
      for (k = 0; k < 2; k++) {
        b = k ? q : a; d = (b[2] + 1) / 2;
        ctx.globalAlpha = 0.5 + 0.5 * d; ctx.fillStyle = '#f1d98a';
        ctx.beginPath(); ctx.arc(b[0], b[1], (2.4 + 2.6 * d) * b[3], 0, 6.2832); ctx.fill();
      }
    }
    for (k = 0; k < N; k++) {
      if (Math.abs(k - cur) > 2.6) continue;
      a = pt(k, 0); d = (a[2] + 1) / 2;
      ctx.globalAlpha = 0.16 + 0.2 * d; ctx.fillStyle = '#d4af37';
      ctx.beginPath(); ctx.arc(a[0], a[1], 18 * a[3], 0, 6.2832); ctx.fill();
      ctx.globalAlpha = 0.7 + 0.3 * d; ctx.fillStyle = '#fff3c4';
      ctx.beginPath(); ctx.arc(a[0], a[1], 6 * a[3], 0, 6.2832); ctx.fill();
    }
    strands(true);
    ctx.globalAlpha = 1;
  }

  function tick() {
    var diff = target - cur;
    if (Math.abs(diff) < 0.0006) { cur = target; render(); running = false; return; }
    cur += diff * 0.16;
    render();
    requestAnimationFrame(tick);
  }
  function kick() { read(); if (!running) { running = true; requestAnimationFrame(tick); } }

  window.addEventListener('scroll', onScroll, { passive: true });
  var rt = 0;
  window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(layout, 80); });
  window.addEventListener('load', layout);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(layout);

  // Keyboard: tabbing into a section brings it round to the front.
  panels.forEach(function (p, i) {
    p.addEventListener('focusin', function () { if (Math.round(target) !== i) go(i); });
  });

  layout();
})();
