/* Close The Market Training — exercise library, part 1: chest & back */
window.TX = window.TX || {};
function X(id, o) { o.id = id; window.TX[id] = o; }

/* ---------------- CHEST ---------------- */
X('bench-press', {
  n: 'Barbell Bench Press', g: 'Chest', m: ['Chest (pecs)', 'Front delts', 'Triceps'], eq: 'Barbell, flat bench, rack with safety arms', type: 'compound',
  d: 'The king of upper-body pushing. A horizontal press that lets you load the chest, front delts and triceps with more weight than almost any other upper-body movement, which makes it the best tool for building pressing strength.',
  steps: [
    'Lie on the bench with your eyes directly under the bar. Feet flat on the floor, slightly behind your knees.',
    'Squeeze your shoulder blades together and down, as if putting them in your back pockets. Keep a small, natural arch in your lower back with your glutes on the bench.',
    'Grip the bar slightly wider than shoulder width, wrists stacked over elbows, bar in the heel of your palm rather than your fingers.',
    'Unrack with straight arms and bring the bar over your shoulders. Take a big breath into your belly and brace.',
    'Lower the bar under control to your lower chest (around nipple line), elbows tucked roughly 45–70 degrees from your body.',
    'Touch your chest lightly without bouncing, then drive the bar up and slightly back towards your face, pushing your feet into the floor.',
    'Lock out over your shoulders, breathe, and repeat. Rack the bar by moving it back into the hooks, not down onto the pins.'
  ],
  cues: ['Bend the bar: try to snap it in half to engage your lats', 'Shoulder blades pinned the whole set', 'Drive with your legs, push yourself away from the bar', 'Same touch point every rep'],
  mistakes: ['Flaring elbows straight out to 90°, which loads the shoulder joint', 'Bouncing the bar off the chest', 'Lifting your glutes off the bench', 'Wrists bent back with the bar in your fingers', 'Training heavy without safety arms or a spotter'],
  why: 'It lets you lift the most weight through a full pressing range, so it is the most efficient way to build pressing strength and a big chest. Progress here is easy to measure, which makes progressive overload simple.',
  vars: [['Close-grip bench', 'Hands shoulder width; shifts more work to the triceps.'], ['Paused bench', '1–2 second pause on the chest; removes momentum and builds strength off the chest.'], ['Larsen press', 'Legs held off the floor; forces upper-body stability, less weight.']],
  swap: ['db-bench', 'machine-press', 'incline-bench']
});
X('incline-bench', {
  n: 'Incline Barbell Bench Press', g: 'Chest', m: ['Upper chest', 'Front delts', 'Triceps'], eq: 'Barbell, incline bench (30–45°), rack', type: 'compound',
  d: 'A bench press on a bench set to about 30 degrees. The angle shifts more of the work onto the upper (clavicular) part of the chest, the area most people lack.',
  steps: [
    'Set the bench to 30° (a steep 45°+ angle turns it into a shoulder press).',
    'Set up exactly like the flat bench: shoulder blades back and down, feet planted, small arch, grip slightly wider than shoulders.',
    'Unrack, brace, and lower the bar to your upper chest just below the collarbones.',
    'Keep elbows slightly tucked and forearms vertical at the bottom.',
    'Press up and slightly back until the bar is over your shoulders.'
  ],
  cues: ['Bar to the top of your chest', 'Chest up to meet the bar', 'Forearms vertical at the bottom'],
  mistakes: ['Bench angle too steep', 'Bar drifting down to the stomach', 'Losing shoulder blade position as you press'],
  why: 'Builds the upper chest, which gives the chest a full, thick look from the collarbone down. Heavier loading than dumbbells for strength-focused plans.',
  vars: [['Low incline (15°)', 'Closer to flat bench; heavier, a little less upper chest.'], ['Incline dumbbell press', 'More range of motion and each arm works on its own.']],
  swap: ['incline-db-press', 'machine-press']
});
X('db-bench', {
  n: 'Dumbbell Bench Press', g: 'Chest', m: ['Chest', 'Front delts', 'Triceps'], eq: 'Dumbbells, flat bench', type: 'compound',
  d: 'A flat press with a dumbbell in each hand. You can lower deeper than with a barbell and each side has to do its own work, which evens out imbalances.',
  steps: [
    'Sit on the end of the bench with the dumbbells on your thighs. Lie back and use your knees to kick them up into position.',
    'Set your shoulder blades back and down, feet planted.',
    'Start with the dumbbells over your chest, palms facing forward or slightly in.',
    'Lower them out and down until you feel a deep stretch across your chest, elbows about 45° from your body.',
    'Press up and slightly inward so the dumbbells finish close together over your chest.'
  ],
  cues: ['Deep stretch at the bottom, control it', 'Press in an arc, not just straight up', 'Ribs down, shoulder blades pinned'],
  mistakes: ['Dropping the dumbbells to the floor dangerously at the end', 'Short range of motion', 'Clanging the dumbbells together at the top and losing tension'],
  why: 'More range of motion and stretch than the barbell, which is great for muscle growth, and safer to push close to failure without a spotter.',
  vars: [['Neutral-grip (palms facing)', 'Kinder on the shoulders and more triceps.'], ['Single-arm', 'One dumbbell at a time; trains your core to resist twisting.']],
  swap: ['bench-press', 'machine-press']
});
X('incline-db-press', {
  n: 'Incline Dumbbell Press', g: 'Chest', m: ['Upper chest', 'Front delts', 'Triceps'], eq: 'Dumbbells, incline bench (30°)', type: 'compound',
  d: 'One of the best upper-chest builders. The incline puts the upper chest in a stronger line of pull and dumbbells give you a deep stretch.',
  steps: [
    'Set the bench to around 30°. Kick the dumbbells up from your thighs as you lie back.',
    'Shoulder blades back and down, chest up, feet planted.',
    'Lower the dumbbells to the sides of your upper chest until you feel a stretch.',
    'Press up and slightly together, finishing over your upper chest.'
  ],
  cues: ['Lead with your chest, not your shoulders', 'Elbows slightly in front of the body', 'Control the lowering for 2–3 seconds'],
  mistakes: ['Bench too steep so it becomes a shoulder press', 'Arching so hard the incline disappears', 'Half reps'],
  why: 'Upper chest development makes a physique look complete from the front and side. Dumbbells let you train it through a long range with low joint stress.',
  vars: [['Neutral grip', 'Easier on the shoulders.'], ['Low incline (15°)', 'More of the whole chest, heavier loading.']],
  swap: ['incline-bench', 'machine-press']
});
X('machine-press', {
  n: 'Machine Chest Press', g: 'Chest', m: ['Chest', 'Front delts', 'Triceps'], eq: 'Chest press machine (plate-loaded or selectorised)', type: 'compound',
  d: 'A guided pressing path that removes the balance demand, so you can push hard and safely close to failure.',
  steps: [
    'Adjust the seat so the handles line up with your mid to lower chest.',
    'Sit tall with your back against the pad, shoulder blades pulled back.',
    'Press the handles forward until your arms are almost straight.',
    'Return slowly until you feel a stretch across your chest, keeping your shoulders back.'
  ],
  cues: ['Shoulders back against the pad', 'Slow on the way back', 'Squeeze your chest at the end of each press'],
  mistakes: ['Seat too high or low, so it hits the shoulders', 'Shoulders rolling forward at lockout', 'Using momentum'],
  why: 'Lets you safely take sets close to failure for maximum muscle growth with very little risk, ideal later in a session when you are tired.',
  vars: [['Incline machine press', 'Upper-chest bias.'], ['Single-arm', 'Fixes side-to-side imbalances.']],
  swap: ['db-bench', 'bench-press']
});
X('cable-fly', {
  n: 'Cable Fly', g: 'Chest', m: ['Chest'], eq: 'Cable station with two handles', type: 'isolation',
  d: 'A chest isolation movement that keeps tension on the pecs through the whole range, especially at the stretched and squeezed positions.',
  steps: [
    'Set both pulleys around shoulder height (or low for an upward fly to target the upper chest).',
    'Grab a handle in each hand and take a step forward into a split stance, chest up.',
    'With a soft bend in your elbows, open your arms wide until you feel a stretch across your chest.',
    'Bring your hands together in a wide hugging arc until they meet in front of your chest.',
    'Pause and squeeze, then return slowly.'
  ],
  cues: ['Hug a big tree', 'Elbows stay soft and fixed, it is not a press', 'Squeeze your hands together at the end'],
  mistakes: ['Bending and straightening the elbows so it turns into a press', 'Going too heavy and losing the stretch', 'Shoulders rolling forward'],
  why: 'The chest\'s main job is bringing the arm across the body. Flies train exactly that with constant tension and little stress on the joints, finishing off the chest after the heavy presses.',
  vars: [['Low-to-high fly', 'Pulleys low, hands finish at chin height; upper chest.'], ['High-to-low fly', 'Pulleys high, hands finish at the hips; lower chest.'], ['Single-arm fly', 'One side at a time for a bigger range.']],
  swap: ['pec-deck']
});
X('pec-deck', {
  n: 'Pec Deck (Machine Fly)', g: 'Chest', m: ['Chest'], eq: 'Pec deck / fly machine', type: 'isolation',
  d: 'A machine fly with a fixed path, the simplest way to isolate the chest and push close to failure safely.',
  steps: [
    'Set the seat so the handles are at chest height and your arms are roughly parallel to the floor.',
    'Sit tall, chest up, shoulder blades back.',
    'With slightly bent elbows, bring the handles together in front of you.',
    'Squeeze for a second, then let them open slowly until you feel a stretch.'
  ],
  cues: ['Chest up, shoulders down', 'Lead with your elbows', 'Control the stretch'],
  mistakes: ['Letting the weight stack slam', 'Shrugging the shoulders up', 'Opening too far past a comfortable stretch'],
  why: 'Pure chest work with no balance or stabilising required, so all the effort goes into the pecs. Great finisher.',
  vars: [['Single-arm pec deck', 'Turn sideways and work one arm at a time.']],
  swap: ['cable-fly']
});
X('dip', {
  n: 'Dip', g: 'Chest', m: ['Lower chest', 'Triceps', 'Front delts'], eq: 'Parallel bars (dip station), dip belt for added weight', type: 'compound',
  d: 'A bodyweight press on parallel bars. Leaning forward makes it a chest exercise; staying upright makes it a triceps exercise.',
  steps: [
    'Grip the bars and jump or step up so your arms are straight and supporting your body.',
    'Lean your torso slightly forward, knees bent and ankles crossed.',
    'Lower yourself by bending your elbows until your shoulders are just below your elbows, or as low as feels comfortable.',
    'Press back up until your arms are straight.'
  ],
  cues: ['Chest proud, shoulders down away from ears', 'Lean forward for chest', 'Control the bottom'],
  mistakes: ['Dropping too deep with the shoulders rolled forward', 'Shrugging', 'Swinging the legs'],
  why: 'A strong compound movement that builds the lower chest and triceps with your own bodyweight, then can be loaded with a belt as you get stronger.',
  vars: [['Assisted dip machine', 'Counterweight helps you; perfect for beginners.'], ['Weighted dip', 'Plates on a belt for strength.'], ['Upright (triceps) dip', 'Torso vertical; more triceps.']],
  swap: ['machine-press', 'db-bench']
});

/* ---------------- BACK ---------------- */
X('deadlift', {
  n: 'Conventional Deadlift', g: 'Back', m: ['Glutes', 'Hamstrings', 'Spinal erectors', 'Upper back', 'Grip'], eq: 'Barbell, plates, chalk (optional), lifting belt (optional)', type: 'compound',
  d: 'Picking a loaded bar up from the floor. It trains almost every muscle on the back of your body and is one of the best tests of total-body strength.',
  steps: [
    'Stand with your feet hip width apart, the bar over the middle of your feet (about 2–3 cm from your shins).',
    'Hinge at the hips and grip the bar just outside your legs, arms straight.',
    'Bend your knees until your shins touch the bar. Keep your hips higher than your knees and shoulders slightly in front of the bar.',
    'Pull the slack out of the bar: lats tight, chest up, back flat. Take a big breath into your belly and brace hard.',
    'Push the floor away with your legs, keeping the bar in contact with your legs as it rises.',
    'Once the bar passes your knees, drive your hips forward and stand tall. Do not lean back.',
    'Lower it by pushing your hips back first, then bending your knees once the bar passes them.'
  ],
  cues: ['Push the floor away, do not pull with your back', 'Protect your armpits: lats tight', 'Bar stays glued to your legs', 'Hips and shoulders rise together'],
  mistakes: ['Rounding the lower back', 'Hips shooting up first so it becomes a stiff-leg pull', 'Bar drifting away from the legs', 'Jerking the bar off the floor', 'Hyperextending at the top'],
  why: 'Builds raw strength through the entire posterior chain (glutes, hamstrings and back), the muscles that keep you strong and resilient for life. Few lifts give as much return per set.',
  vars: [['Sumo deadlift', 'Wide stance, hands inside the legs; more quads and adductors, shorter range.'], ['Trap-bar deadlift', 'Hex bar; more upright and quad-heavy, easier to learn.'], ['Romanian deadlift', 'Starts from the top, no floor contact; more hamstring stretch.']],
  swap: ['trap-bar-deadlift', 'romanian-deadlift']
});
X('trap-bar-deadlift', {
  n: 'Trap Bar Deadlift', g: 'Back', m: ['Quads', 'Glutes', 'Hamstrings', 'Upper back'], eq: 'Trap (hex) bar', type: 'compound',
  d: 'A deadlift inside a hexagonal bar with handles at your sides. The load sits in line with your body, so it is easier to keep a neutral back.',
  steps: [
    'Stand in the centre of the bar, feet hip width.',
    'Hinge and bend your knees to grab the handles, arms straight by your sides.',
    'Chest up, back flat, brace your core.',
    'Drive through your whole foot and stand up tall.',
    'Lower under control by sitting the hips back and bending the knees.'
  ],
  cues: ['Stand up with the bar, do not pull it', 'Chest tall', 'Push through the whole foot'],
  mistakes: ['Squatting too low so it becomes a squat', 'Rounding the back', 'Shrugging at the top'],
  why: 'Gives you most of the strength benefit of a deadlift with less stress on the lower back. Perfect for beginners and people who want to deadlift safely.',
  vars: [['High-handle trap bar', 'Shorter range of motion.'], ['Low-handle trap bar', 'More range, more like a conventional deadlift.']],
  swap: ['deadlift', 'romanian-deadlift']
});
X('barbell-row', {
  n: 'Barbell Bent-Over Row', g: 'Back', m: ['Lats', 'Mid back (rhomboids, traps)', 'Rear delts', 'Biceps'], eq: 'Barbell', type: 'compound',
  d: 'A heavy horizontal pull. You hold a hinged position and row the bar into your torso, which builds a thick, strong back.',
  steps: [
    'Hold the bar with an overhand grip slightly wider than shoulder width.',
    'Hinge at your hips until your torso is around 30–45° above horizontal, knees soft, back flat.',
    'Brace your core and let the bar hang under your shoulders.',
    'Pull the bar towards your lower ribs or belly button, driving your elbows back.',
    'Squeeze your shoulder blades together at the top, then lower under control.'
  ],
  cues: ['Elbows to your back pockets', 'Torso still, no standing up as you pull', 'Squeeze the middle of your back'],
  mistakes: ['Using the hips to swing the weight up', 'Rounding the lower back', 'Standing up more each rep', 'Shrugging instead of rowing'],
  why: 'Builds thickness across the whole back and strengthens the hinge position, which carries over to deadlifts and posture.',
  vars: [['Pendlay row', 'Bar returns to the floor each rep, torso parallel; more explosive.'], ['Underhand row', 'Palms up; more lats and biceps.'], ['Seal row', 'Lying face down on a bench; no lower-back strain.']],
  swap: ['chest-supported-row', 'seated-cable-row', 'db-row']
});
X('chest-supported-row', {
  n: 'Chest-Supported Row', g: 'Back', m: ['Mid back', 'Lats', 'Rear delts'], eq: 'Incline bench with dumbbells, or a T-bar/chest-supported row machine', type: 'compound',
  d: 'A row with your chest on a pad, so you cannot cheat with your hips or lower back. All the work goes into the back.',
  steps: [
    'Set an incline bench to about 30–45° and lie face down with your chest on the pad (or use the machine).',
    'Let the dumbbells or handles hang straight down, arms long.',
    'Row them up towards your hips, driving your elbows back and squeezing your shoulder blades.',
    'Lower slowly until your arms are fully straight and your shoulder blades spread.'
  ],
  cues: ['Chest glued to the pad', 'Pull with your elbows, hands are just hooks', 'Full stretch at the bottom'],
  mistakes: ['Lifting your chest off the pad', 'Shrugging', 'Cutting the range short'],
  why: 'Removes the lower-back fatigue of bent-over rows, so you can train the back hard and often without it limiting your deadlifts and squats.',
  vars: [['T-bar row (chest supported)', 'Heavier loading, neutral grip.'], ['Wide grip, elbows out', 'More upper back and rear delts.'], ['Close grip, elbows in', 'More lats.']],
  swap: ['barbell-row', 'seated-cable-row']
});
X('lat-pulldown', {
  n: 'Lat Pulldown', g: 'Back', m: ['Lats', 'Biceps', 'Rear delts'], eq: 'Lat pulldown machine', type: 'compound',
  d: 'A vertical pull from a cable machine. It builds the lats (the muscles that give your back width) and lets you train the pull-up pattern at any strength level.',
  steps: [
    'Set the thigh pad so your legs are locked in. Grip the bar slightly wider than your shoulders.',
    'Sit down with your arms fully stretched overhead and lean back slightly (around 10–15°).',
    'Pull your shoulder blades down first, then pull the bar to your upper chest by driving your elbows down to your sides.',
    'Pause briefly with your chest up, then let the bar rise slowly until your arms are straight and you feel a stretch in your lats.'
  ],
  cues: ['Elbows down into your back pockets', 'Chest up to the bar', 'Full stretch at the top every rep'],
  mistakes: ['Leaning way back and turning it into a row', 'Pulling behind the neck', 'Using momentum by rocking', 'Not letting the arms straighten at the top'],
  why: 'Wide lats create the V-taper. The pulldown lets you load the vertical pull precisely and reach failure safely, whatever your bodyweight.',
  vars: [['Neutral close-grip pulldown', 'Palms facing, easier on the shoulders; strong lat stretch.'], ['Single-arm cable pulldown', 'Bigger range and focus on each lat.'], ['Underhand grip', 'More biceps involvement.']],
  swap: ['pull-up', 'straight-arm-pulldown']
});
X('pull-up', {
  n: 'Pull-Up', g: 'Back', m: ['Lats', 'Biceps', 'Mid back', 'Core'], eq: 'Pull-up bar (assisted machine or band if needed)', type: 'compound',
  d: 'Pulling your own bodyweight up to a bar. A true test of relative strength and one of the best back builders there is.',
  steps: [
    'Hang from the bar with an overhand grip slightly wider than your shoulders, arms straight.',
    'Brace your core and squeeze your glutes so your body does not swing.',
    'Pull your shoulder blades down, then drive your elbows down to pull your chest towards the bar.',
    'Get your chin over the bar, then lower yourself under control to a full hang.'
  ],
  cues: ['Pull the bar to your chest', 'Elbows to your ribs', 'No kipping, control the way down'],
  mistakes: ['Half reps from a bent-arm hang', 'Kicking and swinging', 'Craning the neck to get the chin over'],
  why: 'Builds a wide, strong back and real-world pulling strength. As you get lighter or stronger, the same exercise keeps getting harder with added weight.',
  vars: [['Chin-up (palms facing you)', 'More biceps, usually stronger.'], ['Assisted pull-up', 'Machine or band helps you; ideal while building strength.'], ['Weighted pull-up', 'Add a belt with plates once you can do 10+ clean reps.']],
  swap: ['lat-pulldown']
});
X('seated-cable-row', {
  n: 'Seated Cable Row', g: 'Back', m: ['Mid back', 'Lats', 'Rear delts', 'Biceps'], eq: 'Cable row station, V-handle or wide bar', type: 'compound',
  d: 'A horizontal pull on a cable with constant tension, great for building the middle of the back with full control.',
  steps: [
    'Sit with your feet on the platform, knees slightly bent, and grab the handle.',
    'Sit tall with your chest up and arms extended, letting your shoulder blades spread forward.',
    'Row the handle to your stomach, driving your elbows back and squeezing your shoulder blades together.',
    'Return slowly until your arms are straight and you feel a stretch across your back, without rounding your lower back.'
  ],
  cues: ['Chest up, sit tall', 'Elbows past your body', 'Reach and stretch, then squeeze'],
  mistakes: ['Rocking back and forth to move the weight', 'Rounding the lower back on the stretch', 'Shrugging the shoulders to your ears'],
  why: 'Thickens the middle of the back and improves posture, with constant tension that is easy on the joints.',
  vars: [['Wide-grip row', 'Elbows wider; more upper back and rear delts.'], ['Single-arm cable row', 'Lets you rotate slightly for a bigger range.']],
  swap: ['chest-supported-row', 'db-row']
});
X('db-row', {
  n: 'Single-Arm Dumbbell Row', g: 'Back', m: ['Lats', 'Mid back', 'Rear delts', 'Biceps'], eq: 'Dumbbell, flat bench', type: 'compound',
  d: 'Rowing one dumbbell at a time with your other hand and knee on a bench. Lets you go heavy with a big range of motion on each side.',
  steps: [
    'Place your left knee and left hand on a flat bench, right foot on the floor, back flat.',
    'Hold the dumbbell in your right hand, arm straight under your shoulder.',
    'Row the dumbbell towards your hip, keeping your elbow close to your side.',
    'Squeeze at the top, then lower slowly to a full stretch. Finish all reps, then switch sides.'
  ],
  cues: ['Pull towards your hip, not your chest', 'Back flat like a table', 'Do not twist your torso open'],
  mistakes: ['Rotating the whole body to heave the weight', 'Rowing straight up to the chest', 'Short range'],
  why: 'Trains each side of the back on its own so a stronger side cannot take over, with a deep lat stretch.',
  vars: [['Kroc row', 'Heavier, higher reps, a little body English; for advanced lifters.'], ['Tripod row', 'Standing, one hand on a bench; heavier loading.']],
  swap: ['seated-cable-row', 'chest-supported-row']
});
X('straight-arm-pulldown', {
  n: 'Straight-Arm Pulldown', g: 'Back', m: ['Lats'], eq: 'Cable station, straight bar or rope', type: 'isolation',
  d: 'An isolation exercise for the lats, keeping your arms straight so your biceps cannot help.',
  steps: [
    'Set a cable pulley at the top and attach a straight bar or rope.',
    'Stand facing the machine, take a step back and hinge forward slightly with a flat back.',
    'With straight arms (a slight bend in the elbows), pull the bar down in an arc to your thighs.',
    'Squeeze your lats, then let the bar rise slowly until your arms are overhead and lats stretched.'
  ],
  cues: ['Arms are levers, keep them straight', 'Pull with your armpits', 'Squeeze at the thighs'],
  mistakes: ['Bending the elbows so it becomes a pushdown', 'Moving the torso up and down', 'Going too heavy'],
  why: 'Teaches you to feel your lats working, which improves every other back exercise, and adds lat volume without tiring your arms.',
  vars: [['Rope version', 'Hands can separate at the bottom for a stronger squeeze.'], ['Dumbbell pullover', 'Lying on a bench; similar lat stretch.']],
  swap: ['lat-pulldown']
});
X('back-extension', {
  n: '45° Back Extension', g: 'Back', m: ['Spinal erectors', 'Glutes', 'Hamstrings'], eq: '45° back extension (hyperextension) bench', type: 'accessory',
  d: 'Hinging over a pad and back up. Strengthens your lower back, glutes and hamstrings with your bodyweight or a plate.',
  steps: [
    'Set the pad just below your hip bones so you can hinge freely. Lock your heels in.',
    'Cross your arms over your chest (or hold a plate).',
    'Hinge forward at the hips with a neutral back until you feel a hamstring stretch.',
    'Squeeze your glutes to come back up until your body forms a straight line. Do not overextend.'
  ],
  cues: ['Hinge from the hips', 'Squeeze your glutes to come up', 'Stop at a straight line'],
  mistakes: ['Hyperextending at the top', 'Pad too high, which blocks the hinge', 'Jerking up quickly'],
  why: 'A resilient lower back and strong glutes protect you in every other lift and in daily life.',
  vars: [['Glute-focused', 'Round the upper back slightly and turn feet out; more glutes.'], ['Weighted', 'Hold a plate or dumbbell to your chest.']],
  swap: ['romanian-deadlift']
});

/* Close The Market Training — exercise library, part 2: shoulders & arms */

/* ---------------- SHOULDERS ---------------- */
X('overhead-press', {
  n: 'Standing Overhead Press', g: 'Shoulders', m: ['Front & side delts', 'Triceps', 'Upper chest', 'Core'], eq: 'Barbell, rack', type: 'compound',
  d: 'Pressing a barbell from your shoulders to overhead while standing. Builds strong shoulders and a stable core at the same time.',
  steps: [
    'Set the bar in a rack at upper-chest height. Grip just outside shoulder width, forearms vertical.',
    'Unrack it so it rests on your front shoulders, elbows slightly in front of the bar.',
    'Feet hip width, squeeze your glutes and brace your abs hard so your lower back does not arch.',
    'Press the bar straight up, moving your head back slightly to let it pass your face.',
    'Once it passes your forehead, push your head through so the bar finishes over the middle of your feet, arms locked.',
    'Lower under control back to your shoulders.'
  ],
  cues: ['Squeeze your glutes, ribs down', 'Head through the window at the top', 'Bar travels in a straight line'],
  mistakes: ['Leaning back and turning it into an incline press', 'Pressing the bar out in front of your face', 'Flaring the elbows wide at the start'],
  why: 'The best strength builder for the shoulders, and it trains your core to stay rigid under load, which carries over to everything you lift.',
  vars: [['Seated barbell press', 'Back supported; less core demand, often heavier.'], ['Push press', 'Small knee dip to drive the bar; heavier, more explosive.'], ['Dumbbell press', 'Each arm independent, more natural path.']],
  swap: ['seated-db-press', 'machine-shoulder-press']
});
X('seated-db-press', {
  n: 'Seated Dumbbell Shoulder Press', g: 'Shoulders', m: ['Front & side delts', 'Triceps'], eq: 'Dumbbells, bench set upright (80–90°)', type: 'compound',
  d: 'Pressing two dumbbells overhead from a seated position. A safe and effective way to build the shoulders.',
  steps: [
    'Set the bench almost upright. Sit with the dumbbells on your thighs and kick them up to shoulder height.',
    'Hold them just outside your shoulders, palms forward or slightly turned in, elbows slightly in front of your body.',
    'Press up until your arms are straight and the dumbbells are over your head.',
    'Lower slowly until the dumbbells are around ear height or slightly lower.'
  ],
  cues: ['Back against the pad', 'Elbows slightly forward, not flared straight out', 'Control the bottom'],
  mistakes: ['Arching the back off the pad', 'Cutting the range short', 'Banging the dumbbells together at the top'],
  why: 'Builds rounded shoulders with a stable, supported position, so you can push close to failure safely.',
  vars: [['Arnold press', 'Rotate palms from facing you to facing forward; more front delt.'], ['Standing dumbbell press', 'More core demand.']],
  swap: ['overhead-press', 'machine-shoulder-press']
});
X('machine-shoulder-press', {
  n: 'Machine Shoulder Press', g: 'Shoulders', m: ['Front & side delts', 'Triceps'], eq: 'Shoulder press machine', type: 'compound',
  d: 'A guided overhead press. No balance needed, so you can put all your effort into the shoulders.',
  steps: [
    'Adjust the seat so the handles start around shoulder height.',
    'Sit tall with your back against the pad.',
    'Press the handles up until your arms are almost straight.',
    'Lower slowly to the start.'
  ],
  cues: ['Back flat on the pad', 'Smooth and controlled', 'Do not lock out hard'],
  mistakes: ['Seat too low, so you start in a deep, stressful position', 'Using momentum', 'Shrugging'],
  why: 'Lets beginners learn the overhead press and lets anyone push hard safely late in a session.',
  vars: [['Single-arm', 'Work one side at a time.']],
  swap: ['seated-db-press']
});
X('lateral-raise', {
  n: 'Dumbbell Lateral Raise', g: 'Shoulders', m: ['Side delts'], eq: 'Dumbbells', type: 'isolation',
  d: 'Raising light dumbbells out to your sides. The most direct way to build the side delts, which make your shoulders look wider.',
  steps: [
    'Stand tall with a dumbbell in each hand at your sides, a slight bend in your elbows.',
    'Lean your torso forward very slightly.',
    'Raise the dumbbells out to your sides, leading with your elbows, until your arms are about parallel to the floor.',
    'Pause briefly, then lower slowly (2–3 seconds).'
  ],
  cues: ['Push the dumbbells out to the walls, not up', 'Lead with your elbows', 'Pinkies level with or slightly above thumbs'],
  mistakes: ['Swinging heavy weights with your body', 'Shrugging the traps up', 'Raising far above shoulder height'],
  why: 'Wide side delts create the broad-shouldered look and improve your shoulder-to-waist ratio. Pressing alone does not train them fully.',
  vars: [['Cable lateral raise', 'Constant tension from the bottom.'], ['Seated lateral raise', 'Removes any body swing.'], ['Lean-away lateral raise', 'Hold a post and lean out; more stretch at the bottom.']],
  swap: ['cable-lateral-raise']
});
X('cable-lateral-raise', {
  n: 'Cable Lateral Raise', g: 'Shoulders', m: ['Side delts'], eq: 'Cable station, single handle', type: 'isolation',
  d: 'A lateral raise on a low cable, which keeps tension on the side delt from the very bottom of the movement.',
  steps: [
    'Set the pulley at the lowest position. Stand side-on and grab the handle with the far hand, cable across your body.',
    'Stand tall with a slight lean away from the machine.',
    'Raise your arm out to the side until it is about parallel to the floor.',
    'Lower slowly, letting the cable pull your hand slightly across your body for a stretch.'
  ],
  cues: ['Elbow leads', 'Slow on the way down', 'Do not let your body twist'],
  mistakes: ['Going too heavy', 'Shrugging', 'Twisting the torso to help'],
  why: 'Cables keep the side delt loaded in the stretched position, where dumbbells feel almost weightless, for more growth from the same effort.',
  vars: [['Behind-the-back cable raise', 'Cable behind you; even bigger stretch.']],
  swap: ['lateral-raise']
});
X('rear-delt-fly', {
  n: 'Reverse Pec Deck (Rear Delt Fly)', g: 'Shoulders', m: ['Rear delts', 'Upper back'], eq: 'Pec deck machine (reverse setting) or dumbbells', type: 'isolation',
  d: 'Opening your arms out behind you. Targets the rear delts, which are often weak and underdeveloped.',
  steps: [
    'Set the pec deck handles to the rear position. Sit facing the pad, chest against it.',
    'Grab the handles with arms straight out in front, slight bend in the elbows.',
    'Sweep your arms out and back in a wide arc until they are in line with your body.',
    'Pause, then return slowly.'
  ],
  cues: ['Push the handles out, not back', 'Keep your shoulder blades still, let the arms move', 'Light and controlled'],
  mistakes: ['Squeezing the shoulder blades so the traps take over', 'Swinging', 'Bending the elbows more as you pull'],
  why: 'Strong rear delts balance out all the pressing, improve posture and give the shoulders a full, 3D look.',
  vars: [['Bent-over dumbbell reverse fly', 'No machine needed.'], ['Cable reverse fly', 'Constant tension with crossed cables.']],
  swap: ['face-pull']
});
X('face-pull', {
  n: 'Face Pull', g: 'Shoulders', m: ['Rear delts', 'Rotator cuff', 'Mid back'], eq: 'Cable station, rope', type: 'isolation',
  d: 'Pulling a rope towards your face with your elbows high. Builds the rear delts and strengthens the small muscles that keep shoulders healthy.',
  steps: [
    'Set the pulley at upper-chest to face height with a rope.',
    'Grab the rope with thumbs pointing back, step back so your arms are straight.',
    'Pull the rope towards your face, separating your hands and driving your elbows high and back.',
    'Finish with your hands beside your ears, like a double-biceps pose. Return slowly.'
  ],
  cues: ['Elbows high', 'Pull the rope apart', 'Finish in a double-biceps pose'],
  mistakes: ['Pulling down to the chest', 'Leaning back to heave the weight', 'Going too heavy'],
  why: 'Counters the forward-rounded shoulders that come from pressing and sitting, keeping your shoulders healthy for the long run.',
  vars: [['Half-kneeling face pull', 'Kneel to remove body cheating.']],
  swap: ['rear-delt-fly']
});

/* ---------------- ARMS ---------------- */
X('ez-curl', {
  n: 'EZ-Bar Curl', g: 'Arms', m: ['Biceps', 'Brachialis'], eq: 'EZ curl bar (or straight barbell)', type: 'isolation',
  d: 'The classic biceps builder. The angled grip of the EZ bar is easier on the wrists than a straight bar.',
  steps: [
    'Stand tall holding the EZ bar on the angled grips, arms straight, palms up.',
    'Pin your elbows by your sides.',
    'Curl the bar up towards your shoulders by bending only at the elbows.',
    'Squeeze at the top, then lower slowly until your arms are fully straight.'
  ],
  cues: ['Elbows stay pinned', 'No swinging', 'Full stretch at the bottom'],
  mistakes: ['Rocking the hips to swing the bar up', 'Elbows drifting forward', 'Half reps'],
  why: 'Lets you load the biceps heavier than dumbbells, the most efficient way to build arm size.',
  vars: [['Straight barbell curl', 'Slightly more biceps, harder on the wrists.'], ['Wide-grip curl', 'More inner (short) head of the biceps.']],
  swap: ['cable-curl', 'incline-db-curl']
});
X('incline-db-curl', {
  n: 'Incline Dumbbell Curl', g: 'Arms', m: ['Biceps (long head)'], eq: 'Dumbbells, incline bench (45–60°)', type: 'isolation',
  d: 'Curling while leaning back on an incline bench, so your arms hang behind your body. This puts the biceps in a big stretch.',
  steps: [
    'Set a bench to 45–60° and lie back with a dumbbell in each hand, arms hanging straight down.',
    'Keep your shoulders back against the pad and palms facing forward.',
    'Curl both dumbbells up without letting your elbows swing forward.',
    'Squeeze, then lower slowly all the way back to a full stretch.'
  ],
  cues: ['Shoulders stay back', 'Elbows point to the floor', 'Own the stretch'],
  mistakes: ['Elbows swinging forward', 'Going too heavy', 'Shortening the bottom'],
  why: 'Training muscles in a stretched position is one of the strongest drivers of growth, and this is the best stretch for the biceps.',
  vars: [['Alternating', 'One arm at a time for more focus.']],
  swap: ['ez-curl', 'cable-curl']
});
X('hammer-curl', {
  n: 'Hammer Curl', g: 'Arms', m: ['Brachialis', 'Brachioradialis (forearm)', 'Biceps'], eq: 'Dumbbells', type: 'isolation',
  d: 'A curl with your palms facing each other. Builds the brachialis and forearms, which add thickness to the arm.',
  steps: [
    'Stand with a dumbbell in each hand, palms facing your body.',
    'Keep your elbows by your sides.',
    'Curl the dumbbells up, keeping the palms facing in the whole time.',
    'Lower slowly to full extension.'
  ],
  cues: ['Thumbs up the whole rep', 'Elbows pinned', 'Control the lowering'],
  mistakes: ['Swinging', 'Turning it into a regular curl', 'Short range'],
  why: 'The brachialis sits under the biceps and pushes it up, making the whole arm look bigger. Hammer curls also build grip strength.',
  vars: [['Cross-body hammer curl', 'Curl across towards the opposite shoulder.'], ['Rope cable hammer curl', 'Constant tension.']],
  swap: ['ez-curl']
});
X('cable-curl', {
  n: 'Cable Curl', g: 'Arms', m: ['Biceps'], eq: 'Cable station, straight bar or EZ attachment', type: 'isolation',
  d: 'A biceps curl on a low cable, keeping tension on the muscle through the whole movement.',
  steps: [
    'Set the pulley at the lowest position and attach a bar.',
    'Stand facing the machine, arms straight, palms up.',
    'Curl the bar up while keeping your elbows by your sides.',
    'Squeeze, then lower slowly until your arms are fully straight.'
  ],
  cues: ['Elbows still', 'Squeeze hard at the top', 'Slow negative'],
  mistakes: ['Leaning back', 'Letting elbows travel forward', 'Rushing reps'],
  why: 'Constant tension at the top and bottom of the curl, so the biceps never get a rest during the set. Great for higher-rep pump work.',
  vars: [['Bayesian curl', 'Cable behind you, step forward; huge biceps stretch.'], ['Single-arm cable curl', 'Fix imbalances.']],
  swap: ['ez-curl', 'incline-db-curl']
});
X('triceps-pushdown', {
  n: 'Triceps Pushdown', g: 'Arms', m: ['Triceps'], eq: 'Cable station, rope or straight bar', type: 'isolation',
  d: 'Pushing a cable down by straightening your elbows. Simple, joint-friendly and effective for the triceps.',
  steps: [
    'Set the pulley at the top and attach a rope or bar.',
    'Stand facing the machine, elbows tucked by your sides, forearms roughly parallel to the floor.',
    'Push down until your arms are fully straight, spreading the rope apart at the bottom.',
    'Squeeze, then let your forearms come back up slowly without moving your elbows.'
  ],
  cues: ['Elbows locked to your sides', 'Only your forearms move', 'Full lockout and squeeze'],
  mistakes: ['Elbows flaring and drifting forward', 'Leaning over to push with bodyweight', 'Not locking out'],
  why: 'The triceps make up about two thirds of the upper arm, so they are key for big arms, and they drive your bench and overhead press.',
  vars: [['Straight-bar pushdown', 'Usually heavier.'], ['Single-arm reverse-grip pushdown', 'Palm up; more focus on the inner head.']],
  swap: ['overhead-triceps', 'skull-crusher']
});
X('overhead-triceps', {
  n: 'Overhead Cable Triceps Extension', g: 'Arms', m: ['Triceps (long head)'], eq: 'Cable station, rope', type: 'isolation',
  d: 'Extending your arms overhead against a cable. Puts the long head of the triceps in a deep stretch.',
  steps: [
    'Set the pulley at about hip height with a rope. Grab it and turn away from the machine.',
    'Step forward into a split stance, lean forward slightly, hands behind your head with elbows pointing forward.',
    'Extend your arms forward and up until they are straight, keeping your elbows in place.',
    'Return slowly, letting your hands go back behind your head for a full stretch.'
  ],
  cues: ['Elbows point forward and stay still', 'Deep stretch behind your head', 'Fully lock out'],
  mistakes: ['Elbows flaring out wide', 'Moving the shoulders instead of the elbows', 'Short range'],
  why: 'The long head of the triceps is only fully stretched with the arm overhead. Training it here adds size you cannot get from pushdowns alone.',
  vars: [['Dumbbell overhead extension', 'Seated, one dumbbell in both hands.'], ['Single-arm cable', 'One side at a time.']],
  swap: ['skull-crusher', 'triceps-pushdown']
});
X('skull-crusher', {
  n: 'EZ-Bar Skull Crusher', g: 'Arms', m: ['Triceps'], eq: 'EZ bar, flat bench', type: 'isolation',
  d: 'Lying on a bench and lowering an EZ bar behind your head by bending your elbows, then extending back up.',
  steps: [
    'Lie on a flat bench holding the EZ bar over your chest with a narrow grip, arms straight.',
    'Let your arms drift back slightly so the bar is over your forehead or eyes.',
    'Bend at the elbows to lower the bar behind your head, keeping your upper arms still.',
    'Extend your elbows to bring the bar back up. Keep tension; do not lock out fully over your face.'
  ],
  cues: ['Upper arms still', 'Lower behind the head, not to the nose', 'Controlled tempo'],
  mistakes: ['Elbows flaring wide', 'Going too heavy and losing control', 'Moving the shoulders to help'],
  why: 'A heavy, effective triceps builder that trains the long head in a lengthened position.',
  vars: [['Dumbbell skull crusher', 'Palms facing; easier on the elbows.'], ['Incline skull crusher', 'On an incline for more stretch.']],
  swap: ['overhead-triceps', 'triceps-pushdown']
});

/* Close The Market Training — exercise library, part 3: legs, glutes, calves & core */

/* ---------------- QUADS / SQUATS ---------------- */
X('back-squat', {
  n: 'Barbell Back Squat', g: 'Legs', m: ['Quads', 'Glutes', 'Adductors', 'Core'], eq: 'Barbell, squat rack with safety arms', type: 'compound',
  d: 'The foundation of lower-body training. Squatting with a barbell on your upper back builds strength and muscle through your whole lower body.',
  steps: [
    'Set the bar in the rack at mid-chest height. Set the safety arms just below the depth you will squat to.',
    'Step under the bar and place it on your upper traps (high bar) or slightly lower across the rear delts (low bar). Grip just outside your shoulders and pull your elbows down.',
    'Stand up to unrack, take two or three small steps back. Feet roughly shoulder width, toes turned out 15–30°.',
    'Big breath into your belly and brace as if about to be punched.',
    'Sit down between your heels by bending at the hips and knees at the same time. Knees track in line with your toes.',
    'Go as deep as you can while keeping your back neutral and heels down, ideally hip crease below knee.',
    'Drive up through your whole foot, keeping your chest up, and stand tall. Breathe between reps.'
  ],
  cues: ['Spread the floor with your feet', 'Knees out over your toes', 'Chest up, stay tight', 'Drive your upper back into the bar'],
  mistakes: ['Knees caving inward', 'Heels lifting', 'Hips shooting up first so you good-morning the weight', 'Losing your brace at the bottom', 'Squatting heavy without safety arms'],
  why: 'No other exercise lets you load the legs this heavily through a full range of motion. It builds strong quads and glutes, bone density and real-life strength.',
  vars: [['High-bar squat', 'Bar higher on the traps, more upright; more quads.'], ['Low-bar squat', 'Bar lower, more forward lean; more hips, usually heavier.'], ['Pause squat', '2-second pause at the bottom; builds strength out of the hole.']],
  swap: ['hack-squat', 'leg-press', 'goblet-squat']
});
X('front-squat', {
  n: 'Front Squat', g: 'Legs', m: ['Quads', 'Glutes', 'Upper back', 'Core'], eq: 'Barbell, squat rack', type: 'compound',
  d: 'A squat with the bar held on the front of your shoulders. The upright torso makes it extremely quad-focused.',
  steps: [
    'Set the bar at upper-chest height. Step in so it sits on your front delts, close to your throat.',
    'Use a clean grip (fingertips under the bar, elbows high) or cross your arms over the bar.',
    'Unrack, step back, feet shoulder width.',
    'Brace and squat straight down, keeping your elbows high and torso upright.',
    'Drive up, leading with your elbows.'
  ],
  cues: ['Elbows up', 'Sit straight down between your heels', 'Stay tall'],
  mistakes: ['Elbows dropping, so the bar rolls forward', 'Rounding the upper back', 'Heels lifting'],
  why: 'Builds big quads and a strong upper back with less load on the spine than a back squat.',
  vars: [['Cross-arm grip', 'Easier for people with tight wrists.'], ['Safety-bar squat', 'Similar upright position with a special bar.']],
  swap: ['hack-squat', 'goblet-squat']
});
X('goblet-squat', {
  n: 'Goblet Squat', g: 'Legs', m: ['Quads', 'Glutes', 'Core'], eq: 'Dumbbell or kettlebell', type: 'compound',
  d: 'A squat holding one dumbbell at your chest. The front load teaches perfect squat mechanics and is ideal for beginners.',
  steps: [
    'Hold a dumbbell vertically against your chest by one end, elbows pointing down.',
    'Stand with your feet slightly wider than shoulder width, toes slightly out.',
    'Squat down between your knees, keeping your chest up and elbows inside your knees.',
    'Drive back up through your whole foot.'
  ],
  cues: ['Elbows between the knees', 'Chest tall', 'Sit down, not back'],
  mistakes: ['Letting the dumbbell pull you forward', 'Heels lifting', 'Knees caving'],
  why: 'The easiest way to learn to squat with good form. It builds the pattern you will use on every other squat variation.',
  vars: [['Heels-elevated goblet squat', 'Heels on a plate; more quads, easier depth.']],
  swap: ['leg-press', 'back-squat']
});
X('hack-squat', {
  n: 'Hack Squat (Machine)', g: 'Legs', m: ['Quads', 'Glutes'], eq: 'Hack squat machine', type: 'compound',
  d: 'A machine squat on an angled sled with your back supported. It lets you train the quads very hard without balancing a bar.',
  steps: [
    'Step in with your back against the pad and shoulders under the shoulder pads.',
    'Place your feet shoulder width in the middle of the platform.',
    'Release the safety handles. Lower yourself by bending your knees until your thighs are at least parallel to the platform.',
    'Drive through your whole foot back to the top without fully locking out your knees.'
  ],
  cues: ['Back flat on the pad', 'Knees track over toes', 'Go deep and control it'],
  mistakes: ['Cutting depth short', 'Heels lifting', 'Bouncing out of the bottom'],
  why: 'A stable, supported way to push your quads to their limit. Great for muscle growth and for lifters who struggle with barbell squats.',
  vars: [['Narrow, low foot placement', 'More quads.'], ['Higher foot placement', 'More glutes and hamstrings.'], ['Pendulum squat', 'Similar machine with a curved path.']],
  swap: ['leg-press', 'back-squat']
});
X('leg-press', {
  n: 'Leg Press', g: 'Legs', m: ['Quads', 'Glutes', 'Adductors'], eq: 'Leg press machine (45° sled)', type: 'compound',
  d: 'Pushing a weighted platform away with your legs while seated. Lets you load the legs heavily with your back fully supported.',
  steps: [
    'Sit with your back and hips flat against the pad.',
    'Place your feet shoulder width in the middle of the platform.',
    'Release the safety catches. Lower the platform by bending your knees towards your chest, as deep as you can without your lower back lifting off the pad.',
    'Press back up through your whole foot until your legs are almost straight. Do not lock your knees out.'
  ],
  cues: ['Lower back stays on the pad', 'Push through your heels and mid-foot', 'Control the descent'],
  mistakes: ['Lowering so deep your hips roll up off the seat', 'Locking the knees out hard', 'Tiny half reps with huge weight'],
  why: 'Lots of leg muscle can be trained with very little fatigue on your back, so you can add volume after squats or train hard safely.',
  vars: [['High and wide feet', 'More glutes and hamstrings.'], ['Low and narrow feet', 'More quads.'], ['Single-leg press', 'Fixes imbalances.']],
  swap: ['hack-squat', 'goblet-squat']
});
X('bulgarian-split-squat', {
  n: 'Bulgarian Split Squat', g: 'Legs', m: ['Quads', 'Glutes', 'Adductors'], eq: 'Dumbbells, flat bench', type: 'compound',
  d: 'A single-leg squat with your back foot raised on a bench. Brutal, effective, and one of the best exercises for legs and glutes.',
  steps: [
    'Stand about two steps in front of a bench, holding dumbbells at your sides.',
    'Place the top of your back foot on the bench.',
    'Lower your back knee towards the floor by bending your front leg, keeping your front heel down.',
    'Go down until your front thigh is about parallel to the floor, then drive up through your front foot.',
    'Finish all reps on one leg, then switch.'
  ],
  cues: ['Front foot does the work', 'Slight forward lean for glutes, upright for quads', 'Control the bottom'],
  mistakes: ['Front foot too close, so the heel lifts', 'Pushing off the back foot', 'Wobbling: slow down and use less weight'],
  why: 'Training each leg on its own builds balance, fixes imbalances and hits the glutes and quads hard with less load on your spine.',
  vars: [['Glute-focused', 'Longer stance and lean forward.'], ['Quad-focused', 'Shorter stance and stay upright.'], ['Smith machine version', 'More stable, easier to load.']],
  swap: ['walking-lunge', 'leg-press']
});
X('walking-lunge', {
  n: 'Walking Lunge', g: 'Legs', m: ['Quads', 'Glutes', 'Hamstrings'], eq: 'Dumbbells, open floor space', type: 'compound',
  d: 'Stepping forward into a lunge, then driving through into the next step. Builds the legs and glutes while improving balance and coordination.',
  steps: [
    'Stand tall with a dumbbell in each hand.',
    'Take a long step forward and lower your back knee towards the floor.',
    'Your front knee should stay over your mid-foot, torso slightly forward.',
    'Drive through your front foot to stand and step straight into the next lunge with the other leg.'
  ],
  cues: ['Long, controlled steps', 'Back knee kisses the floor', 'Push the floor away with the front foot'],
  mistakes: ['Short steps that overload the knees', 'Front heel lifting', 'Rushing and losing balance'],
  why: 'A functional, athletic leg exercise that builds the glutes and quads and challenges balance.',
  vars: [['Reverse lunge', 'Step backwards; easier on the knees.'], ['Static split squat', 'No stepping; easier to control.']],
  swap: ['bulgarian-split-squat', 'leg-press']
});
X('leg-extension', {
  n: 'Leg Extension', g: 'Legs', m: ['Quads (especially rectus femoris)'], eq: 'Leg extension machine', type: 'isolation',
  d: 'Straightening your knees against a padded lever. Isolates the quads.',
  steps: [
    'Adjust the seat so your knees line up with the machine\'s pivot point.',
    'Set the pad just above your ankles.',
    'Hold the handles and extend your legs until they are straight.',
    'Squeeze your quads for a second, then lower slowly.'
  ],
  cues: ['Squeeze at the top', 'Slow on the way down', 'Hips stay on the seat'],
  mistakes: ['Kicking the weight up with momentum', 'Hips lifting off the seat', 'Not reaching full extension'],
  why: 'It trains the rectus femoris, part of the quads that squats do not fully hit, and adds leg volume without tiring your back.',
  vars: [['Single-leg', 'Fix imbalances.'], ['Lean back', 'Recline the seat for more stretch on the rectus femoris.']],
  swap: ['hack-squat']
});

/* ---------------- HAMSTRINGS / GLUTES ---------------- */
X('romanian-deadlift', {
  n: 'Romanian Deadlift (RDL)', g: 'Legs', m: ['Hamstrings', 'Glutes', 'Spinal erectors'], eq: 'Barbell or dumbbells', type: 'compound',
  d: 'A hip hinge where you lower the bar down your legs with soft knees until your hamstrings are fully stretched. One of the best hamstring and glute builders.',
  steps: [
    'Stand tall holding the bar with an overhand grip at hip width, feet hip width apart.',
    'Soften your knees slightly and keep them at that angle the whole time.',
    'Push your hips back as far as you can, letting the bar slide down your thighs, back flat.',
    'Lower until you feel a strong stretch in your hamstrings, usually just below the knees to mid-shin.',
    'Drive your hips forward to stand back up, squeezing your glutes at the top.'
  ],
  cues: ['Hips back, like closing a car door with your bum', 'Bar stays on your legs', 'Feel the hamstring stretch', 'Neutral neck: look at the floor a few metres ahead'],
  mistakes: ['Bending the knees more and more so it becomes a squat', 'Rounding the back to get lower', 'Bar drifting away from the legs'],
  why: 'Trains the hamstrings and glutes in a deep stretch with heavy load, which is excellent for growth and protects you from hamstring injuries.',
  vars: [['Dumbbell RDL', 'Easier to learn, more natural path.'], ['Single-leg RDL', 'Balance and glute focus.'], ['Stiff-leg deadlift', 'Bar returns to the floor each rep.']],
  swap: ['leg-curl', 'back-extension']
});
X('leg-curl', {
  n: 'Seated Leg Curl', g: 'Legs', m: ['Hamstrings'], eq: 'Seated leg curl machine (or lying)', type: 'isolation',
  d: 'Bending your knees against a padded lever. Isolates the hamstrings, and the seated version trains them in a stretched position.',
  steps: [
    'Adjust the seat so your knees line up with the pivot point. Lower the thigh pad onto your thighs.',
    'Place the ankle pad on the back of your lower legs, just above the heels.',
    'Curl your heels down and back as far as you can.',
    'Squeeze, then let your legs straighten slowly.'
  ],
  cues: ['Lean your chest forward slightly for more stretch', 'Squeeze at the bottom', 'Slow negatives'],
  mistakes: ['Hips lifting', 'Swinging the weight', 'Partial range'],
  why: 'The RDL trains the hamstrings at the hip; the curl trains them at the knee. You need both for complete, strong hamstrings that resist injury.',
  vars: [['Lying leg curl', 'Face down; slightly less stretch, still effective.'], ['Nordic curl', 'Bodyweight, very hard; strong injury prevention.']],
  swap: ['romanian-deadlift']
});
X('hip-thrust', {
  n: 'Barbell Hip Thrust', g: 'Glutes', m: ['Glutes', 'Hamstrings'], eq: 'Barbell, bench, bar pad (or hip thrust machine)', type: 'compound',
  d: 'Driving a barbell up with your hips while your upper back rests on a bench. The best exercise for loading the glutes directly and heavily.',
  steps: [
    'Sit on the floor with your upper back against the edge of a bench, the padded bar over your hip crease.',
    'Bend your knees and plant your feet flat, about hip width, so your shins will be vertical at the top.',
    'Tuck your chin and brace your core.',
    'Drive through your heels and squeeze your glutes to lift your hips until your body is flat from shoulders to knees.',
    'Pause and squeeze for one second, then lower under control.'
  ],
  cues: ['Ribs down, chin tucked', 'Push through your heels', 'Squeeze your glutes hard at the top, no lower-back arching'],
  mistakes: ['Overarching the lower back at the top', 'Feet too far forward (hamstrings take over) or too close (quads take over)', 'Not reaching full hip extension'],
  why: 'The glutes are strongest at full hip extension, where squats barely load them. Hip thrusts build glute size and strength like no other exercise.',
  vars: [['Hip thrust machine', 'Easier set-up, same benefit.'], ['Single-leg hip thrust', 'Bodyweight or light; fixes imbalances.'], ['Glute bridge', 'From the floor; shorter range, easy to set up.']],
  swap: ['cable-kickback', 'romanian-deadlift']
});
X('hip-abduction', {
  n: 'Hip Abduction Machine', g: 'Glutes', m: ['Glute medius', 'Glute minimus', 'Upper glutes'], eq: 'Hip abduction machine', type: 'isolation',
  d: 'Pushing your knees outward against a machine. Builds the side and upper glutes, which shape the hips and stabilise the knees.',
  steps: [
    'Sit in the machine with the pads on the outside of your knees.',
    'Lean your torso slightly forward for more glute focus.',
    'Push your knees out as wide as you can.',
    'Squeeze, then return slowly without letting the stack touch down.'
  ],
  cues: ['Lean forward slightly', 'Push out wide', 'Slow return'],
  mistakes: ['Bouncing the weight', 'Tiny partial reps', 'Sitting bolt upright (less glute)'],
  why: 'Strong glute medius improves knee tracking in squats and lunges and builds a rounder, wider glute shape.',
  vars: [['Cable hip abduction', 'Standing with an ankle strap.'], ['Banded abductions', 'Mini band above the knees, anywhere.']],
  swap: ['cable-kickback']
});
X('cable-kickback', {
  n: 'Cable Glute Kickback', g: 'Glutes', m: ['Glutes'], eq: 'Cable station, ankle strap', type: 'isolation',
  d: 'Kicking one leg back against a low cable. Isolates the glutes and is easy to feel.',
  steps: [
    'Attach an ankle strap to a low pulley and to one ankle.',
    'Face the machine, hold on, and hinge forward slightly.',
    'Kick your working leg back and slightly out, squeezing your glute.',
    'Stop before your lower back arches, then return slowly. Complete all reps, then switch.'
  ],
  cues: ['Kick back and up from the hip', 'Squeeze the glute at the top', 'Do not arch your back'],
  mistakes: ['Swinging the leg', 'Arching the lower back to get more range', 'Going too heavy'],
  why: 'Lets you add focused glute volume with almost no fatigue, a good finisher on lower-body days.',
  vars: [['Machine kickback', 'Glute kickback machine.']],
  swap: ['hip-abduction', 'hip-thrust']
});

/* ---------------- CALVES ---------------- */
X('standing-calf-raise', {
  n: 'Standing Calf Raise', g: 'Calves', m: ['Calves (gastrocnemius)'], eq: 'Standing calf raise machine or Smith machine with a step', type: 'isolation',
  d: 'Rising onto your toes with straight legs. Trains the big calf muscle, the gastrocnemius.',
  steps: [
    'Stand with the balls of your feet on the platform edge, heels hanging off, shoulders under the pads.',
    'Lower your heels as far as you can for a deep stretch. Pause for one to two seconds.',
    'Push up onto your toes as high as possible.',
    'Squeeze for one second, then lower slowly.'
  ],
  cues: ['Pause in the stretch', 'All the way up on your big toe', 'Knees straight but not locked'],
  mistakes: ['Bouncing', 'Tiny range of motion', 'Bending the knees to help'],
  why: 'Calves respond to full range and pauses. Proper calf training balances the look of the legs and supports your ankles.',
  vars: [['Leg press calf raise', 'Push with the toes on a leg press.'], ['Single-leg dumbbell calf raise', 'On a step, no machine needed.']],
  swap: ['seated-calf-raise']
});
X('seated-calf-raise', {
  n: 'Seated Calf Raise', g: 'Calves', m: ['Calves (soleus)'], eq: 'Seated calf raise machine', type: 'isolation',
  d: 'A calf raise with bent knees, which shifts the work onto the soleus, the deeper calf muscle.',
  steps: [
    'Sit with the balls of your feet on the platform, pad on your lower thighs.',
    'Release the safety and lower your heels for a deep stretch.',
    'Push up as high as possible onto your toes.',
    'Pause, then lower slowly.'
  ],
  cues: ['Deep stretch at the bottom', 'Full height at the top', 'Controlled tempo'],
  mistakes: ['Bouncing', 'Half reps'],
  why: 'The soleus makes up a large part of the calf. Training it with bent knees adds size and ankle strength that standing raises miss.',
  vars: [['Dumbbell seated calf raise', 'Dumbbells on your knees, toes on a plate.']],
  swap: ['standing-calf-raise']
});

/* ---------------- CORE ---------------- */
X('cable-crunch', {
  n: 'Cable Crunch', g: 'Core', m: ['Abs (rectus abdominis)'], eq: 'Cable station, rope', type: 'isolation',
  d: 'Kneeling under a high cable and crunching down. Lets you load the abs and progress them like any other muscle.',
  steps: [
    'Attach a rope to a high pulley. Kneel facing the machine and hold the rope by your head.',
    'Keep your hips still and high.',
    'Crunch down by curling your ribs towards your pelvis, bringing your elbows towards your thighs.',
    'Squeeze your abs, then return slowly to a stretch.'
  ],
  cues: ['Curl your spine, do not bow at the hips', 'Ribs to pelvis', 'Breathe out as you crunch'],
  mistakes: ['Sitting back on your heels so the hips do the work', 'Pulling with your arms', 'Going too heavy'],
  why: 'Loaded ab training builds visible, strong abs and a core that can brace under heavy lifts.',
  vars: [['Machine crunch', 'Seated ab crunch machine.'], ['Decline crunch', 'Bodyweight on a decline bench.']],
  swap: ['hanging-leg-raise', 'plank']
});
X('hanging-leg-raise', {
  n: 'Hanging Leg Raise', g: 'Core', m: ['Abs (especially lower)', 'Hip flexors'], eq: 'Pull-up bar or captain\'s chair', type: 'isolation',
  d: 'Hanging from a bar and raising your legs. A tough, effective ab exercise.',
  steps: [
    'Hang from a bar with a shoulder-width grip (or use a captain\'s chair with your back on the pad).',
    'Brace your core to stop swinging.',
    'Raise your knees (easier) or straight legs (harder) up towards your chest, curling your pelvis up at the top.',
    'Lower slowly without swinging.'
  ],
  cues: ['Curl your pelvis up, do not just lift your legs', 'No swinging', 'Slow on the way down'],
  mistakes: ['Using momentum', 'Only lifting the legs to 90° without curling the pelvis'],
  why: 'Trains the abs through spinal flexion from the bottom up and builds grip strength at the same time.',
  vars: [['Hanging knee raise', 'Bent knees; easier.'], ['Captain\'s chair raise', 'Back supported; easiest.'], ['Toes to bar', 'Advanced, full range.']],
  swap: ['cable-crunch', 'plank']
});
X('plank', {
  n: 'Plank', g: 'Core', m: ['Abs', 'Obliques', 'Deep core'], eq: 'Floor / mat', type: 'isolation',
  d: 'Holding a straight-body position on your forearms. Trains your core to resist bending, the same skill you use to brace under a heavy bar.',
  steps: [
    'Lie face down and prop yourself on your forearms, elbows under your shoulders.',
    'Lift your hips so your body forms a straight line from head to heels.',
    'Squeeze your glutes and pull your belly button in and up.',
    'Hold, breathing steadily, without letting your hips sag or pike up.'
  ],
  cues: ['Squeeze glutes and quads', 'Ribs down', 'Push the floor away with your forearms'],
  mistakes: ['Hips sagging', 'Hips piked up high', 'Holding your breath'],
  why: 'Builds the bracing strength that protects your spine during squats, deadlifts and presses.',
  vars: [['RKC plank', 'Squeeze everything as hard as possible for 10–20 seconds; harder than a long plank.'], ['Side plank', 'Targets the obliques.'], ['Weighted plank', 'Plate on your back.']],
  swap: ['pallof-press', 'cable-crunch']
});
X('pallof-press', {
  n: 'Pallof Press', g: 'Core', m: ['Obliques', 'Deep core'], eq: 'Cable station, single handle', type: 'isolation',
  d: 'Pressing a cable out in front of you while it tries to twist you. Trains your core to resist rotation.',
  steps: [
    'Set a cable at chest height. Stand side-on, holding the handle at your chest with both hands.',
    'Step away so there is tension, feet shoulder width, knees soft.',
    'Press the handle straight out in front of your chest without letting your body rotate.',
    'Hold for two seconds, bring it back in. Do all reps, then switch sides.'
  ],
  cues: ['Stay square, do not twist', 'Glutes and abs tight', 'Slow and controlled'],
  mistakes: ['Rotating towards the machine', 'Standing too close (no tension)'],
  why: 'A strong anti-rotation core protects your lower back and makes you more stable in every lift.',
  vars: [['Half-kneeling Pallof', 'More stable, more core isolation.']],
  swap: ['plank']
});

/* Close The Market Training — splits, day templates and prescriptions */
window.TP = (function () {
  // role: main = heavy compound, sec = secondary compound, acc = accessory, iso = isolation, core = core
  var D = {
    // ---- Full body
    fbA: { n: 'Full Body A', f: 'full', l: [['back-squat','main'],['bench-press','main'],['chest-supported-row','sec'],['romanian-deadlift','sec'],['lateral-raise','iso'],['triceps-pushdown','iso'],['hammer-curl','iso'],['cable-crunch','core']] },
    fbB: { n: 'Full Body B', f: 'full', l: [['deadlift','main'],['overhead-press','main'],['lat-pulldown','sec'],['bulgarian-split-squat','acc'],['incline-db-press','acc'],['leg-curl','iso'],['ez-curl','iso'],['hanging-leg-raise','core']] },
    fbC: { n: 'Full Body C', f: 'full', l: [['hack-squat','main'],['incline-db-press','sec'],['pull-up','sec'],['hip-thrust','sec'],['seated-cable-row','acc'],['rear-delt-fly','iso'],['overhead-triceps','iso'],['standing-calf-raise','iso']] },
    fbD: { n: 'Full Body D', f: 'full', l: [['trap-bar-deadlift','main'],['db-bench','sec'],['db-row','sec'],['walking-lunge','acc'],['seated-db-press','acc'],['leg-extension','iso'],['cable-curl','iso'],['pallof-press','core']] },
    // ---- Push / Pull / Legs
    pushA: { n: 'Push A', f: 'push', l: [['bench-press','main'],['seated-db-press','sec'],['incline-db-press','acc'],['cable-fly','iso'],['lateral-raise','iso'],['triceps-pushdown','iso'],['overhead-triceps','iso']] },
    pullA: { n: 'Pull A', f: 'pull', l: [['barbell-row','main'],['lat-pulldown','sec'],['seated-cable-row','acc'],['face-pull','iso'],['ez-curl','iso'],['hammer-curl','iso'],['straight-arm-pulldown','iso']] },
    legsA: { n: 'Legs A', f: 'legs', l: [['back-squat','main'],['romanian-deadlift','sec'],['leg-press','acc'],['leg-curl','iso'],['leg-extension','iso'],['standing-calf-raise','iso'],['cable-crunch','core']] },
    pushB: { n: 'Push B', f: 'push', l: [['overhead-press','main'],['incline-db-press','sec'],['machine-press','acc'],['cable-lateral-raise','iso'],['pec-deck','iso'],['skull-crusher','iso'],['triceps-pushdown','iso']] },
    pullB: { n: 'Pull B', f: 'pull', l: [['deadlift','main'],['pull-up','sec'],['chest-supported-row','acc'],['db-row','acc'],['rear-delt-fly','iso'],['incline-db-curl','iso'],['cable-curl','iso']] },
    legsB: { n: 'Legs B', f: 'legs', l: [['hack-squat','main'],['hip-thrust','sec'],['bulgarian-split-squat','acc'],['leg-curl','iso'],['leg-extension','iso'],['seated-calf-raise','iso'],['hanging-leg-raise','core']] },
    // ---- Upper / Lower
    upA: { n: 'Upper A', f: 'upper', l: [['bench-press','main'],['barbell-row','main'],['seated-db-press','sec'],['lat-pulldown','sec'],['lateral-raise','iso'],['ez-curl','iso'],['triceps-pushdown','iso']] },
    loA: { n: 'Lower A', f: 'lower', l: [['back-squat','main'],['romanian-deadlift','sec'],['leg-press','acc'],['leg-curl','iso'],['standing-calf-raise','iso'],['cable-crunch','core']] },
    upB: { n: 'Upper B', f: 'upper', l: [['overhead-press','main'],['pull-up','sec'],['incline-db-press','sec'],['chest-supported-row','acc'],['cable-lateral-raise','iso'],['hammer-curl','iso'],['overhead-triceps','iso']] },
    loB: { n: 'Lower B', f: 'lower', l: [['deadlift','main'],['hack-squat','sec'],['hip-thrust','sec'],['bulgarian-split-squat','acc'],['leg-extension','iso'],['seated-calf-raise','iso'],['hanging-leg-raise','core']] },
    upC: { n: 'Upper C', f: 'upper', l: [['incline-bench','main'],['seated-cable-row','sec'],['machine-press','acc'],['db-row','acc'],['rear-delt-fly','iso'],['incline-db-curl','iso'],['skull-crusher','iso']] },
    loC: { n: 'Lower C', f: 'lower', l: [['front-squat','main'],['romanian-deadlift','sec'],['walking-lunge','acc'],['leg-curl','iso'],['leg-extension','iso'],['standing-calf-raise','iso'],['plank','core']] },
    // ---- PHUL
    upP: { n: 'Upper Power', f: 'upper', mode: 'strength', l: [['bench-press','main'],['barbell-row','main'],['overhead-press','sec'],['lat-pulldown','sec'],['ez-curl','iso'],['skull-crusher','iso']] },
    loP: { n: 'Lower Power', f: 'lower', mode: 'strength', l: [['back-squat','main'],['deadlift','main'],['leg-press','acc'],['leg-curl','iso'],['standing-calf-raise','iso'],['plank','core']] },
    upH: { n: 'Upper Hypertrophy', f: 'upper', mode: 'hypertrophy', l: [['incline-db-press','sec'],['chest-supported-row','sec'],['cable-fly','iso'],['seated-cable-row','acc'],['lateral-raise','iso'],['incline-db-curl','iso'],['overhead-triceps','iso']] },
    loH: { n: 'Lower Hypertrophy', f: 'lower', mode: 'hypertrophy', l: [['hack-squat','sec'],['romanian-deadlift','sec'],['bulgarian-split-squat','acc'],['leg-extension','iso'],['leg-curl','iso'],['seated-calf-raise','iso'],['cable-crunch','core']] },
    // ---- Body-part split
    chest: { n: 'Chest', f: 'push', l: [['bench-press','main'],['incline-db-press','sec'],['machine-press','acc'],['dip','acc'],['cable-fly','iso'],['pec-deck','iso']] },
    back: { n: 'Back', f: 'pull', l: [['deadlift','main'],['pull-up','sec'],['barbell-row','sec'],['seated-cable-row','acc'],['straight-arm-pulldown','iso'],['face-pull','iso']] },
    legs5: { n: 'Legs', f: 'legs', l: [['back-squat','main'],['romanian-deadlift','sec'],['leg-press','acc'],['leg-extension','iso'],['leg-curl','iso'],['standing-calf-raise','iso'],['hanging-leg-raise','core']] },
    shoulders: { n: 'Shoulders', f: 'push', l: [['overhead-press','main'],['seated-db-press','sec'],['lateral-raise','iso'],['cable-lateral-raise','iso'],['rear-delt-fly','iso'],['face-pull','iso']] },
    arms: { n: 'Arms & Abs', f: 'arms', l: [['ez-curl','iso'],['skull-crusher','iso'],['incline-db-curl','iso'],['triceps-pushdown','iso'],['hammer-curl','iso'],['overhead-triceps','iso'],['cable-crunch','core']] },
    // ---- Arnold
    cbA: { n: 'Chest & Back A', f: 'upper', l: [['bench-press','main'],['pull-up','sec'],['incline-db-press','sec'],['barbell-row','sec'],['cable-fly','iso'],['straight-arm-pulldown','iso']] },
    saA: { n: 'Shoulders & Arms A', f: 'arms', l: [['overhead-press','main'],['lateral-raise','iso'],['ez-curl','iso'],['skull-crusher','iso'],['rear-delt-fly','iso'],['hammer-curl','iso'],['triceps-pushdown','iso']] },
    cbB: { n: 'Chest & Back B', f: 'upper', l: [['incline-bench','main'],['chest-supported-row','sec'],['db-bench','sec'],['lat-pulldown','sec'],['pec-deck','iso'],['db-row','acc']] },
    saB: { n: 'Shoulders & Arms B', f: 'arms', l: [['seated-db-press','sec'],['cable-lateral-raise','iso'],['incline-db-curl','iso'],['overhead-triceps','iso'],['face-pull','iso'],['cable-curl','iso'],['dip','acc']] }
  };

  var S = {
    fb3: { n: 'Full Body', days: ['fbA','fbB','fbC'], sched: ['Mon','Wed','Fri'],
      why: 'You train every muscle three times a week with plenty of rest between sessions. Hitting each muscle often is one of the best ways to build strength and muscle, especially in your first years of training.',
      pros: ['Each muscle trained 3× a week', 'Miss a session and nothing gets skipped', 'Lots of practice on the big lifts'],
      cons: ['Longer sessions', 'Less room for lots of isolation work per muscle'] },
    ppl3: { n: 'Push / Pull / Legs', days: ['pushA','pullA','legsA'], sched: ['Mon','Wed','Fri'],
      why: 'Each session focuses on one movement type: pushing muscles, pulling muscles, or legs. Simple to follow, and each session can go deep on its muscles.',
      pros: ['Focused, simple sessions', 'Lots of volume per muscle each session'],
      cons: ['Each muscle only trained once a week on 3 days', 'Missing a day means a muscle group waits two weeks'] },
    ulf3: { n: 'Upper / Lower / Full Body', days: ['upA','loA','fbC'], sched: ['Mon','Wed','Fri'],
      why: 'A hybrid: one upper day, one lower day and one full-body day. Every muscle gets trained twice a week with varied sessions.',
      pros: ['Every muscle 2× a week', 'Good balance of focus and frequency'],
      cons: ['Slightly more complex to follow'] },
    ul4: { n: 'Upper / Lower', days: ['upA','loA','upB','loB'], sched: ['Mon','Tue','Thu','Fri'],
      why: 'Two upper and two lower sessions a week. Every muscle is trained twice a week, which research supports as a sweet spot for muscle growth, with enough recovery between sessions.',
      pros: ['Each muscle 2× a week', 'Great balance of volume and recovery', 'Works for every goal and level'],
      cons: ['Upper days can get long if you add lots of arm work'] },
    phul: { n: 'PHUL (Power + Hypertrophy, Upper / Lower)', days: ['upP','loP','upH','loH'], sched: ['Mon','Tue','Thu','Fri'],
      why: 'Two heavy "power" days to build strength on the big lifts and two higher-rep "hypertrophy" days to build muscle. Ideal if you want to get strong and look strong.',
      pros: ['Builds strength and size together', 'Each muscle 2× a week', 'Clear structure'],
      cons: ['Power days are demanding', 'Not ideal for complete beginners'] },
    fb4: { n: 'Full Body ×4', days: ['fbA','fbB','fbC','fbD'], sched: ['Mon','Tue','Thu','Fri'],
      why: 'Four varied full-body sessions. High frequency with shorter, lower-volume sessions, good for athletic goals and people who like variety.',
      pros: ['Very high frequency', 'Varied sessions', 'Shorter workouts possible'],
      cons: ['Back-to-back full-body days can be tiring on legs'] },
    pplul: { n: 'Push / Pull / Legs + Upper / Lower', days: ['pushA','pullA','legsA','upB','loB'], sched: ['Mon','Tue','Wed','Fri','Sat'],
      why: 'A Push / Pull / Legs block followed by an Upper / Lower block. Every muscle is hit about twice a week across five focused sessions, one of the most effective 5-day structures.',
      pros: ['Each muscle ~2× a week', 'Focused sessions with lots of variety', 'Great for building muscle'],
      cons: ['Five days a week takes commitment'] },
    bro5: { n: 'Body-Part Split (Chest, Back, Legs, Shoulders, Arms)', days: ['chest','back','legs5','shoulders','arms'], sched: ['Mon','Tue','Wed','Thu','Fri'],
      why: 'The classic bodybuilding split: one muscle group per day. Each session hammers one area with lots of volume.',
      pros: ['Huge focus and pump per muscle', 'Enjoyable and simple', 'Short recovery overlap between days'],
      cons: ['Each muscle is only trained once a week, which research suggests is less effective than twice for most people', 'Miss a day and that muscle waits two weeks'] },
    ppl6: { n: 'Push / Pull / Legs ×2', days: ['pushA','pullA','legsA','pushB','pullB','legsB'], sched: ['Mon','Tue','Wed','Thu','Fri','Sat'],
      why: 'The full Push / Pull / Legs cycle twice a week with different exercises each time. High volume and frequency for serious muscle growth.',
      pros: ['Each muscle 2× a week', 'Two variations of every session', 'Lots of total weekly volume'],
      cons: ['Six days a week needs good sleep and nutrition to recover', 'Only one rest day'] },
    ul6: { n: 'Upper / Lower ×3', days: ['upA','loA','upB','loB','upC','loC'], sched: ['Mon','Tue','Wed','Thu','Fri','Sat'],
      why: 'Three upper and three lower sessions a week. Each muscle is trained three times a week, excellent for practising the big lifts and building strength.',
      pros: ['Each muscle 3× a week', 'Very frequent practice on key lifts'],
      cons: ['Demanding on recovery', 'Lower-body sessions come round quickly'] },
    arnold6: { n: 'Arnold Split', days: ['cbA','saA','legsA','cbB','saB','legsB'], sched: ['Mon','Tue','Wed','Thu','Fri','Sat'],
      why: 'Made famous by Arnold Schwarzenegger: chest and back together, shoulders and arms together, then legs, repeated twice a week. Opposing muscles are trained together for big pumps.',
      pros: ['Each muscle 2× a week', 'Chest and back supersets save time', 'Great for advanced lifters chasing size'],
      cons: ['High volume per session', 'Arms get a lot of work; watch your elbows'] }
  };

  var BY_DAYS = { 3: ['fb3','ppl3','ulf3'], 4: ['ul4','phul','fb4'], 5: ['pplul','bro5'], 6: ['ppl6','ul6','arnold6'] };

  function recommend(days, goal, exp) {
    if (days == 3) return 'fb3';
    if (days == 4) return (goal === 'strength' || goal === 'powerbuilding') && exp !== 'beginner' ? 'phul' : 'ul4';
    if (days == 5) return 'pplul';
    return goal === 'strength' ? 'ul6' : 'ppl6';
  }

  // Sets, reps, effort and rest by goal and role
  var P = {
    strength: { main: [4,'3–5','RPE 7–8 (leave 2–3 reps in the tank)','3–5 min'], sec: [3,'5–8','RPE 7–8 (2–3 in reserve)','2–3 min'], acc: [3,'8–10','1–2 reps in reserve','90–120 s'], iso: [2,'10–15','1–2 reps in reserve','60–90 s'], core: [3,'8–12','Controlled','60 s'] },
    hypertrophy: { main: [3,'6–10','1–2 reps in reserve','2–3 min'], sec: [3,'8–12','1–2 reps in reserve','2 min'], acc: [3,'10–12','0–2 reps in reserve','90 s'], iso: [3,'12–15','0–1 reps in reserve (last set to failure)','60–90 s'], core: [3,'10–15','Controlled','60 s'] },
    powerbuilding: { main: [4,'4–6','RPE 8 top set, then back-off sets','3 min'], sec: [3,'6–10','1–2 reps in reserve','2–3 min'], acc: [3,'8–12','1–2 reps in reserve','90 s'], iso: [3,'10–15','0–1 reps in reserve','60–90 s'], core: [3,'10–15','Controlled','60 s'] },
    fatloss: { main: [3,'6–8','1–2 reps in reserve (keep it heavy to keep muscle)','2–3 min'], sec: [3,'8–12','1–2 reps in reserve','90–120 s'], acc: [3,'10–12','1–2 reps in reserve','60–90 s'], iso: [2,'12–15','0–1 reps in reserve','60 s'], core: [3,'10–15','Controlled','45–60 s'] },
    general: { main: [3,'5–8','2–3 reps in reserve','2–3 min'], sec: [3,'8–10','2 reps in reserve','2 min'], acc: [3,'10–12','2 reps in reserve','90 s'], iso: [2,'12–15','1–2 reps in reserve','60 s'], core: [3,'10–15','Controlled','60 s'] }
  };
  var UNILATERAL = { 'bulgarian-split-squat': 1, 'walking-lunge': 1, 'db-row': 1, 'cable-kickback': 1, 'pallof-press': 1, 'cable-lateral-raise': 1 };

  function prescribe(exId, role, goal, exp, sex, dayMode) {
    var g = dayMode || goal;
    var r = (P[g] || P.hypertrophy)[role] || P.hypertrophy.iso;
    var sets = r[0], reps = r[1], effort = r[2], rest = r[3];
    if (exp === 'beginner') { sets = Math.max(role === 'main' ? 3 : 2, sets - 1); effort = role === 'core' ? effort : '2–3 reps in reserve while you learn the movement'; }
    if (exp === 'advanced' && (role === 'main' || role === 'sec')) sets += 1;
    if (sex === 'female' && (role === 'iso' || role === 'acc') && g !== 'strength') rest = role === 'iso' ? '45–75 s' : '60–90 s';
    if (exId === 'plank') reps = exp === 'beginner' ? '20–30 s hold' : '30–45 s hold';
    if (UNILATERAL[exId]) reps += ' each side';
    return { sets: sets, reps: reps, effort: effort, rest: rest };
  }

  var BEGINNER_SWAP = { 'deadlift': 'trap-bar-deadlift', 'barbell-row': 'chest-supported-row', 'pull-up': 'lat-pulldown', 'front-squat': 'goblet-squat', 'skull-crusher': 'overhead-triceps', 'dip': 'machine-press' };
  var CAP = { 45: 5, 60: 6, 75: 7, 90: 8 };

  function build(o) {
    // o: {sex, goal, exp, days, split, mins, emphasis, swaps}
    var split = S[o.split] || S[recommend(o.days, o.goal, o.exp)];
    var cap = CAP[o.mins] || 6;
    var out = split.days.map(function (key, di) {
      var day = D[key], list = day.l.map(function (x) { return [x[0], x[1]]; });
      if (o.exp === 'beginner') list.forEach(function (x) { if (BEGINNER_SWAP[x[0]]) x[0] = BEGINNER_SWAP[x[0]]; });
      var lowerDay = /lower|legs|full/.test(day.f), upperDay = /upper|push|pull|arms/.test(day.f);
      if (o.emphasis === 'lower') {
        if (lowerDay) {
          if (!list.some(function (x) { return x[0] === 'hip-thrust'; })) list.splice(1, 0, ['hip-thrust', 'sec']);
          var ci = list.findIndex(function (x) { return x[1] === 'core'; });
          list.splice(ci < 0 ? list.length : ci, 0, ['hip-abduction', 'iso']);
          if (day.f !== 'full') list.splice(Math.min(4, list.length), 0, ['cable-kickback', 'iso']);
        }
        if (upperDay && day.f !== 'arms') { var li = -1; list.forEach(function (x, i) { if (x[1] === 'iso' && /curl|triceps|skull|pushdown/.test(x[0])) li = i; }); if (li > -1) list.splice(li, 1); }
      } else if (o.emphasis === 'upper') {
        if (upperDay) {
          if (!list.some(function (x) { return /lateral/.test(x[0]); })) list.splice(2, 0, ['lateral-raise', 'iso']);
          if (!list.some(function (x) { return /curl/.test(x[0]); }) && day.f !== 'push') list.splice(3, 0, ['incline-db-curl', 'iso']);
        }
        if (lowerDay && day.f !== 'full') { var ii = -1; list.forEach(function (x, i) { if (x[1] === 'iso' && /calf|extension/.test(x[0])) ii = i; }); if (ii > -1) list.splice(ii, 1); }
      }
      // dedupe
      var seen = {}; list = list.filter(function (x) { if (seen[x[0]]) return false; seen[x[0]] = 1; return true; });
      list = list.slice(0, cap);
      var items = list.map(function (x, si) {
        var slot = key + ':' + si;
        var id = (o.swaps && o.swaps[slot]) || x[0];
        return { slot: slot, id: id, base: x[0], role: x[1], rx: prescribe(id, x[1], o.goal, o.exp, o.sex, day.mode) };
      });
      return { key: key, name: day.n, day: split.sched[di], focus: day.f, mode: day.mode, items: items };
    });
    return { split: split, splitId: o.split, days: out };
  }

  return { D: D, S: S, BY_DAYS: BY_DAYS, recommend: recommend, build: build, prescribe: prescribe };
})();

/* Stability rating (1-5) and how to make each plan exercise more stable */
window.TST = {
  'bench-press': [3, 'Pin your shoulder blades and drive your feet into the floor. For hypertrophy sets to failure, the Smith machine version (rating 5) removes the balancing.'],
  'incline-bench': [3, 'Set your upper back hard into the bench. The incline Smith press (5) is the most stable way to push the upper chest to failure.'],
  'db-bench': [2, 'Set your shoulder blades and press in a controlled arc. Neutral grip adds stability; a machine press is the stable swap.'],
  'incline-db-press': [2, 'Control the dumbbells over the joint. Swap to an incline Smith or machine press when you want to train to failure.'],
  'machine-press': [5, 'Already fully guided. Keep your shoulders back against the pad so the chest, not the shoulders, does the work.'],
  'cable-fly': [3, 'Use a split stance and brace. Sitting on an upright bench between the cables, or the pec deck, is even more stable.'],
  'pec-deck': [5, 'Fully guided. Sit tall and keep your shoulders down so the chest takes all the load.'],
  'dip': [3, 'Grip hard and keep your body still; no swinging. The assisted or seated dip machine is the stable option.'],
  'deadlift': [3, 'Brace before every rep and keep your lats tight. Stability here comes from your trunk, not a machine.'],
  'trap-bar-deadlift': [4, 'The load sits in line with your body, which makes it more stable than a straight bar.'],
  'barbell-row': [2, 'Your lower back holds the position, which limits how hard you can push. The chest-supported row (5) takes it out completely.'],
  'chest-supported-row': [5, 'Keep your chest glued to the pad: that is what removes your lower back and lets the back muscles work to failure.'],
  'lat-pulldown': [4, 'Lock your thighs under the pad and keep your torso still so only your arms and shoulder blades move.'],
  'pull-up': [3, 'Squeeze your glutes and brace your abs to stop swinging. The assisted pull-up machine is more stable.'],
  'seated-cable-row': [4, 'Sit tall and keep your torso still; rocking takes tension off the back.'],
  'db-row': [3, 'Use your free hand and knee on the bench as a solid base and keep your torso square.'],
  'straight-arm-pulldown': [3, 'Hinge slightly and keep your torso still; only your arms move.'],
  'back-extension': [5, 'Your feet are locked in; move slowly and stop at a straight line.'],
  'overhead-press': [2, 'Squeeze your glutes and brace hard. Seated, Smith (5) or machine versions are far more stable for hypertrophy.'],
  'seated-db-press': [3, 'Keep your back against the pad. The Smith or machine shoulder press is the stable swap.'],
  'machine-shoulder-press': [5, 'Fully guided. Keep your back on the pad and press smoothly.'],
  'lateral-raise': [2, 'Sit down, or lie chest-down on an incline bench, to remove body swing. Machine laterals are rated 5.'],
  'cable-lateral-raise': [3, 'Hold the machine with your free hand and stay still; only the working arm moves.'],
  'rear-delt-fly': [5, 'Chest on the pad, arms do the work. Do not squeeze your shoulder blades so hard that the traps take over.'],
  'face-pull': [3, 'Stand in a split stance or half kneel to stop leaning back.'],
  'ez-curl': [3, 'Pin your elbows to your sides so elbow flexion is the only movement. For the biceps to work hardest, a preacher curl (4–5) locks the upper arm in place.'],
  'incline-db-curl': [4, 'The bench supports your torso; keep your shoulders back and elbows pointing to the floor so the biceps do pure elbow flexion.'],
  'hammer-curl': [2, 'Brace your elbows against your sides, or sit on a bench, to stop swinging.'],
  'cable-curl': [3, 'Keep your elbows still and lean slightly into the cable for a steady base.'],
  'triceps-pushdown': [4, 'Pin your elbows to your sides; only your forearms move.'],
  'overhead-triceps': [3, 'Use a split stance and keep your elbows pointing forward. Seated dumbbell or machine versions are more stable.'],
  'skull-crusher': [3, 'Keep your upper arms fixed; the bench is your base.'],
  'back-squat': [3, 'Brace, grip the floor with your feet and use safety arms. The Smith, hack squat or leg press (5) let you push the quads to failure safely.'],
  'front-squat': [2, 'Keep your elbows high and your upper back tight. A hack squat is the stable quad swap.'],
  'goblet-squat': [3, 'The dumbbell counterbalances you, which makes it easy to stay upright.'],
  'hack-squat': [5, 'Fully supported. Keep your back flat on the pad and go deep.'],
  'leg-press': [5, 'Fully supported. Keep your lower back on the pad at the bottom.'],
  'bulgarian-split-squat': [2, 'Hold a dumbbell in one hand and a rack with the other, or do it in the Smith machine (5).'],
  'walking-lunge': [2, 'Take controlled steps. Reverse lunges or Smith split squats are more stable.'],
  'leg-extension': [5, 'Fully guided. Hold the handles and keep your hips on the seat.'],
  'romanian-deadlift': [3, 'Brace and keep the bar on your legs. A Smith machine RDL is more stable.'],
  'leg-curl': [5, 'Fully guided. Keep your hips down so the hamstrings do all the work.'],
  'hip-thrust': [4, 'Plant your upper back and feet. The hip thrust machine or Smith version (5) is even steadier.'],
  'hip-abduction': [5, 'Fully guided. Lean slightly forward and hold the handles.'],
  'cable-kickback': [3, 'Hold the machine firmly and keep your torso still; the machine kickback is rated 5.'],
  'standing-calf-raise': [5, 'Fully guided. Pause in the stretch.'],
  'seated-calf-raise': [5, 'Fully guided. Pause in the stretch.'],
  'cable-crunch': [4, 'Keep your hips fixed so only your spine curls.'],
  'hanging-leg-raise': [2, 'Brace to stop swinging, or use a captain\'s chair (4) with your back supported.'],
  'plank': [4, 'Squeeze your glutes and push the floor away.'],
  'pallof-press': [3, 'Stand square with a wide base. Half kneeling is more stable.']
};

/* Close The Market Training — app */
(function () {
  var KEY = 'ctm_training_v1';
  var st = load();
  function load() {
    var d = { sex: 'male', goal: 'hypertrophy', exp: 'intermediate', days: 4, split: '', mins: 60, emphasis: '', swaps: {}, logs: {}, built: false };
    try { var s = JSON.parse(localStorage.getItem(KEY) || 'null'); if (s) d = Object.assign(d, s); } catch (e) {}
    d.swaps = d.swaps || {}; d.logs = d.logs || {};
    return d;
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) {} }
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  var GOALS = {
    strength: { n: 'Strength', d: 'Lift heavier on the big lifts' },
    hypertrophy: { n: 'Build muscle', d: 'Maximise muscle size (hypertrophy)' },
    powerbuilding: { n: 'Strength & size', d: 'Powerbuilding: get strong and look it' },
    fatloss: { n: 'Lose fat, keep muscle', d: 'Get lean while protecting muscle' },
    general: { n: 'General fitness', d: 'Feel fitter, stronger and healthier' }
  };
  var EXP = { beginner: ['Beginner', 'Under 1 year of consistent training'], intermediate: ['Intermediate', '1–3 years'], advanced: ['Advanced', '3+ years, near your genetic potential'] };
  var EMPH = { balanced: ['Balanced', 'Even focus on every muscle'], lower: ['Glutes & legs', 'Extra glute and leg work'], upper: ['Upper body', 'Extra shoulders and arms'] };
  var ROLE = { main: 'Main lift', sec: 'Compound', acc: 'Accessory', iso: 'Isolation', core: 'Core' };

  function defaultEmph() { return st.sex === 'female' ? 'lower' : 'balanced'; }

  /* ---------- builder form ---------- */
  function seg(name, opts, cur) {
    return '<div class="tt-seg" role="radiogroup">' + opts.map(function (o) {
      return '<button type="button" role="radio" aria-checked="' + (String(cur) === String(o[0])) + '" data-set="' + name + '" data-val="' + o[0] + '"><b>' + o[1] + '</b>' + (o[2] ? '<small>' + o[2] + '</small>' : '') + '</button>';
    }).join('') + '</div>';
  }
  function renderForm() {
    var emph = st.emphasis || defaultEmph();
    var rec = TP.recommend(st.days, st.goal, st.exp);
    var splits = TP.BY_DAYS[st.days];
    var curSplit = splits.indexOf(st.split) > -1 ? st.split : rec;
    $('#tt-form').innerHTML =
      '<div class="tt-field"><span class="tt-lbl">1. Sex</span>' + seg('sex', [['male', 'Male'], ['female', 'Female']], st.sex) + '</div>' +
      '<div class="tt-field"><span class="tt-lbl">2. Main goal</span>' + seg('goal', Object.keys(GOALS).map(function (k) { return [k, GOALS[k].n, GOALS[k].d]; }), st.goal) + '</div>' +
      '<div class="tt-field"><span class="tt-lbl">3. Experience</span>' + seg('exp', Object.keys(EXP).map(function (k) { return [k, EXP[k][0], EXP[k][1]]; }), st.exp) + '</div>' +
      '<div class="tt-field"><span class="tt-lbl">4. Days per week</span>' + seg('days', [[3, '3 days'], [4, '4 days'], [5, '5 days'], [6, '6 days']], st.days) + '</div>' +
      '<div class="tt-field"><span class="tt-lbl">5. Training split</span>' + seg('split', splits.map(function (k) { return [k, TP.S[k].n, k === rec ? 'Recommended for you' : '']; }), curSplit) + '</div>' +
      '<div class="tt-field"><span class="tt-lbl">6. Session length</span>' + seg('mins', [[45, '45 min'], [60, '60 min'], [75, '75 min'], [90, '90 min']], st.mins) + '</div>' +
      '<div class="tt-field"><span class="tt-lbl">7. Focus</span>' + seg('emphasis', Object.keys(EMPH).map(function (k) { return [k, EMPH[k][0], EMPH[k][1]]; }), emph) + '</div>' +
      (st.exp === 'beginner' && st.days >= 5 ? '<p class="tt-warn">As a beginner, 3–4 days a week is usually all you need to make fast progress. 5–6 days works only if you can recover from it.</p>' : '') +
      '<button type="button" class="btn btn-primary tt-build" id="tt-build">' + (st.built ? 'Rebuild my plan' : 'Build my plan') + '</button>';
  }

  /* ---------- plan ---------- */
  function currentPlan() {
    var splits = TP.BY_DAYS[st.days];
    var split = splits.indexOf(st.split) > -1 ? st.split : TP.recommend(st.days, st.goal, st.exp);
    return TP.build({ sex: st.sex, goal: st.goal, exp: st.exp, days: st.days, split: split, mins: st.mins, emphasis: st.emphasis || defaultEmph(), swaps: st.swaps });
  }
  function weekStrip(plan) {
    var all = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return '<div class="tt-week">' + all.map(function (d) {
      var day = plan.days.filter(function (x) { return x.day === d; })[0];
      return '<a class="tt-wd' + (day ? ' on' : '') + '"' + (day ? ' href="#day-' + day.key + '"' : '') + '><span>' + d + '</span><b>' + (day ? esc(day.name) : 'Rest') + '</b></a>';
    }).join('') + '</div>';
  }
  function vols(plan) {
    var v = {};
    plan.days.forEach(function (d) { d.items.forEach(function (it) { var g = TX[it.id].g; v[g] = (v[g] || 0) + it.rx.sets; }); });
    return '<div class="tt-vol">' + Object.keys(v).map(function (g) { return '<span><b>' + v[g] + '</b> ' + esc(g) + '</span>'; }).join('') + '</div>';
  }
  function exCard(it, di, ii) {
    var x = TX[it.id], logs = st.logs[it.id] || [];
    var last = logs[logs.length - 1];
    var alts = [it.base].concat(TX[it.base].swap || []).filter(function (v, i, a) { return a.indexOf(v) === i && TX[v]; });
    if (alts.indexOf(it.id) < 0) alts.unshift(it.id);
    var swapSel = '<label class="tt-swap">Swap for <select data-swap="' + it.slot + '">' + alts.map(function (a) { return '<option value="' + a + '"' + (a === it.id ? ' selected' : '') + '>' + esc(TX[a].n) + (a === it.base ? ' (default)' : '') + '</option>'; }).join('') + '</select></label>';
    return '<details class="tt-ex" id="ex-' + it.slot.replace(':', '-') + '">' +
      '<summary><span class="tt-num">' + (ii + 1) + '</span><span class="tt-exn"><b>' + esc(x.n) + '</b><small>' + esc(ROLE[it.role]) + ' · ' + esc(x.m.slice(0, 3).join(', ')) + '</small></span>' +
      '<span class="tt-rx"><b>' + it.rx.sets + ' × ' + esc(it.rx.reps) + '</b><small>Rest ' + esc(it.rx.rest) + '</small></span></summary>' +
      '<div class="tt-exb">' +
        '<p class="tt-effort"><span>Effort</span>' + esc(it.rx.effort) + '</p>' +
        '<p class="tt-desc">' + esc(x.d) + '</p>' + stabHtml(it.id) +
        '<div class="tt-cols"><div><h4>How to do it</h4><ol>' + x.steps.map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ol></div>' +
        '<div><h4>Form cues</h4><ul class="tt-good">' + x.cues.map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ul>' +
        '<h4>Common mistakes</h4><ul class="tt-bad">' + x.mistakes.map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ul></div></div>' +
        '<h4>Why it\'s in your plan</h4><p>' + esc(x.why) + '</p>' +
        '<h4>Variations and how they differ</h4><dl class="tt-vars">' + x.vars.map(function (v) { return '<dt>' + esc(v[0]) + '</dt><dd>' + esc(v[1]) + '</dd>'; }).join('') + '</dl>' +
        '<p class="tt-meta">MUSCLES // ' + esc(x.m.join(' · ').toUpperCase()) + '<br>EQUIPMENT // ' + esc(x.eq.toUpperCase()) + '</p>' +
        swapSel +
        '<div class="tt-log"><h4>Log your last session</h4>' +
          '<div class="tt-logrow"><label>Weight (kg)<input type="number" inputmode="decimal" step="0.5" min="0" data-lw="' + it.id + '" value="' + (last ? last.w : '') + '"></label>' +
          '<label>Reps per set<input type="text" inputmode="numeric" placeholder="e.g. 10, 9, 8" data-lr="' + it.id + '" value="' + (last ? esc(last.r.join(', ')) : '') + '"></label>' +
          '<button type="button" class="btn btn-secondary btn-sm" data-logsave="' + it.id + '" data-reps="' + esc(it.rx.reps) + '" data-sets="' + it.rx.sets + '">Save</button></div>' +
          '<p class="tt-next" id="next-' + it.id + '">' + (last ? nextAdvice(it.id, last, it.rx) : 'Log your weight and reps after each session and you will get your next target here.') + '</p>' +
          (logs.length > 1 ? '<p class="tt-hist">' + logs.slice(-5).map(function (l) { return esc(l.date) + ': ' + l.w + 'kg × ' + esc(l.r.join('/')); }).join(' &nbsp;·&nbsp; ') + '</p>' : '') +
        '</div>' +
      '</div></details>';
  }
  function stabHtml(id) {
    var t = (window.TST || {})[id]; if (!t) return '';
    var m = ''; for (var i = 0; i < 5; i++) m += '<i class="' + (i < t[0] ? 'on' : '') + '"></i>';
    return '<div class="tt-stab"><span class="tt-stabh">STABILITY ' + t[0] + '/5 <span class="tt-meter" role="img" aria-label="Stability ' + t[0] + ' out of 5">' + m + '</span></span>' + esc(t[1]) + '</div>';
  }
  function repRange(s) { var m = String(s).match(/(\d+)\s*[–-]\s*(\d+)/); return m ? [+m[1], +m[2]] : null; }
  function incFor(id) {
    var x = TX[id];
    if (/Dumbbell|dumbbell/.test(x.eq) && !/Barbell|barbell/.test(x.eq)) return '2 kg (the next pair of dumbbells)';
    if (x.type === 'isolation') return 'the smallest jump available (one pin or 1–2.5 kg)';
    if (x.g === 'Legs' || x.g === 'Glutes' || id === 'deadlift' || id === 'trap-bar-deadlift') return '2.5–5 kg';
    return '2.5 kg (1.25 kg each side)';
  }
  function nextAdvice(id, last, rx) {
    var rr = repRange(rx.reps); if (!rr || !last.r.length) return '';
    var low = rr[0], top = rr[1];
    var allTop = last.r.length >= rx.sets && last.r.every(function (r) { return r >= top; });
    var anyLow = last.r.some(function (r) { return r < low; });
    if (allTop) return '<b>Next session: add weight.</b> You hit ' + top + '+ reps on every set. Add ' + incFor(id) + ' and aim for ' + low + '–' + (low + 2) + ' reps.';
    if (anyLow && last.r.filter(function (r) { return r < low; }).length >= 2) return '<b>Next session: same weight, focus on form.</b> Several sets fell below ' + low + ' reps. If that happens again next time, drop the weight by about 5–10% and build back up.';
    return '<b>Next session: same ' + last.w + ' kg, beat your reps.</b> Add at least one rep to any set. When every set reaches ' + top + ', add weight.';
  }
  function renderPlan() {
    var plan = currentPlan();
    var g = GOALS[st.goal], sp = plan.split;
    var html = '<div class="tt-sum"><p class="label">Your plan</p><h2 class="font-serif text-3xl sm:text-4xl leading-[1.08] mt-3"><span class="hl-muted">' + esc(sp.n) + ',</span> <span class="hl-bright">' + st.days + ' days a week</span></h2>' +
      '<p class="tt-chips"><span>' + esc(g.n) + '</span><span>' + esc(EXP[st.exp][0]) + '</span><span>' + (st.sex === 'female' ? 'Female' : 'Male') + '</span><span>' + st.mins + ' min sessions</span><span>' + esc(EMPH[st.emphasis || defaultEmph()][0]) + ' focus</span></p>' +
      '<p class="tt-why">' + esc(sp.why) + '</p>' + weekStrip(plan) +
      '<p class="tt-sub">Hard sets per muscle group each week</p>' + vols(plan) +
      '<div class="tt-actions"><a class="btn btn-secondary btn-sm" href="/exercise-library">Exercise library</a><button type="button" class="btn btn-secondary btn-sm" id="tt-expand">Open every exercise</button><button type="button" class="btn btn-secondary btn-sm" id="tt-print">Print / save as PDF</button>' + (Object.keys(st.swaps).length ? '<button type="button" class="btn btn-secondary btn-sm" id="tt-reset">Reset swaps</button>' : '') + '</div></div>';
    html += plan.days.map(function (d, di) {
      var mode = d.mode === 'strength' ? '<span class="tt-mode">Heavy day</span>' : d.mode === 'hypertrophy' ? '<span class="tt-mode">Volume day</span>' : '';
      var sets = d.items.reduce(function (a, it) { return a + it.rx.sets; }, 0);
      return '<section class="tt-day" id="day-' + d.key + '"><header><p class="tt-dlabel">' + d.day + ' // DAY ' + (di + 1) + '</p><h3>' + esc(d.name) + ' ' + mode + '</h3><p class="tt-dmeta">' + d.items.length + ' exercises · ' + sets + ' working sets · warm up first (see below)</p></header>' +
        d.items.map(function (it, ii) { return exCard(it, di, ii); }).join('') + '</section>';
    }).join('');
    $('#tt-plan').innerHTML = html;
    renderGuides(plan);
  }

  /* ---------- guides ---------- */
  var OVERLOAD = {
    hypertrophy: ['Double progression', 'Every exercise has a rep range, e.g. 8–12. Start with a weight you can lift for the bottom of the range with 1–2 reps left in the tank. Each session, try to add reps. When you hit the top of the range on every set with good form, add the smallest weight jump and drop back to the bottom of the range. Repeat. More reps, then more weight, forever.'],
    fatloss: ['Hold your strength', 'In a calorie deficit, the goal is to keep the weight on the bar. Use double progression the same way, but count it as a win if you hold your numbers. Strength that stays up means muscle stays on while the fat comes off. Do not chase pumps with light weights; keep the main lifts heavy.'],
    strength: ['Load progression', 'Beginners: add 2.5 kg to upper-body lifts and 2.5–5 kg to lower-body lifts every session while you hit all your reps. Once that stalls, move to weekly progression: hit your target reps at RPE 7–8, then add weight the following week. Every 4–6 weeks, take a deload week. Strength is a skill: perfect, repeatable reps beat ugly heavy ones.'],
    powerbuilding: ['Top set + back-off sets', 'On your main lift, work up to one heavy "top set" at RPE 8 in the rep range, then drop the weight by 10–15% for the remaining sets. When the top set feels like RPE 7, add weight next week. All other exercises use double progression: fill the rep range, then add weight.'],
    general: ['Steady progression', 'Use double progression: stay in the rep range with 2 reps in the tank, add a rep each session, and add weight when you reach the top of the range on all sets. Small, consistent wins add up to big changes over months.']
  };
  var FOOD = {
    hypertrophy: ['Eat in a small surplus', 'Aim for about 200–300 calories above maintenance. That is enough to fuel growth without adding much fat. Expect to gain roughly 0.25–0.5% of your bodyweight a month.'],
    strength: ['Eat at maintenance or slightly above', 'Strength needs fuel. Eating at or a little above maintenance keeps your energy and recovery high so your lifts keep climbing.'],
    powerbuilding: ['Eat in a small surplus', 'Heavy strength work plus volume needs fuel. Aim for about 200–300 calories above maintenance with high protein.'],
    fatloss: ['Eat in a moderate deficit', 'Aim for about 300–500 calories below maintenance (around 0.5–1% of bodyweight lost a week). Keep protein high and keep lifting heavy: the training tells your body to keep its muscle, so the weight you lose comes from fat.'],
    general: ['Eat around maintenance', 'Match what you burn, prioritise protein and whole foods, and let your training do the rest. You will slowly lose fat and gain muscle at the same time.']
  };
  function nutritionGuide() {
    var f = FOOD[st.goal] || FOOD.general;
    return '<div class="tt-g"><p class="label">Training + nutrition</p><h3>Your plan only works if you feed it</h3><p>Training is the <b>signal</b>: hard sets near failure tell your body to build muscle. Food is the <b>material</b>: muscle is built from protein during the 24–48 hours after you train. Without enough protein and the right calories, the signal has nothing to build with. That is why your plan and your nutrition have to point at the same goal.</p><h4>For your goal: ' + esc(f[0]) + '</h4><p>' + esc(f[1]) + '</p><ul class="tt-list"><li><b>Protein:</b> 1.6–2.2 g per kg of bodyweight every day, split across 3–5 meals.</li><li><b>Before you train:</b> carbs 1–2 hours before (rice, oats, fruit) so you have the energy for hard sets.</li><li><b>After you train:</b> a protein-rich meal within a few hours.</li><li><b>Consistency:</b> hitting your targets most days beats being perfect for a week.</li></ul><p><a href="/nutrition-tool">Set your exact calories and macros, and plan a week of meals for this goal, in Close The Market Nutrition</a>.</p></div>';
  }
  function renderGuides(plan) {
    var o = OVERLOAD[st.goal];
    var sp = plan.split;
    $('#tt-guides').innerHTML =
      '<div class="tt-g"><p class="label">The science</p><h3>Where muscle is actually built</h3><p>Your muscles are switched on by motor neurons. Each neuron and the fibres it controls is a <b>motor unit</b>, and they are recruited from smallest to largest. The biggest, high-threshold units control the fibres with the most potential to grow, and they only switch on when the effort is high: either a heavy weight, or a lighter weight taken close to failure.</p><p>As you approach failure your reps slow down. That is the moment the high-threshold fibres are both recruited and contracting slowly, which puts the most tension on them. Those final ~5 reps before failure are where most of the growth signal comes from. That is why every set in your plan has an effort target: <b>finish most sets 0–3 reps from failure</b>, or you never reach the reps that matter.</p><ul class="tt-list"><li><b>Stability matters.</b> When an exercise is stable (Smith machine, chest-supported row, preacher curl), your nervous system stops holding back force for balance and lets the target muscle work at full power. Each exercise below has a stability rating and tips to make it steadier.</li><li><b>Lock the joints that should not move.</b> On a curl, the biceps\' job is elbow flexion. Pin your elbows (or brace them on a bench) so the shoulder cannot take over.</li><li><b>Focus on the muscle</b> on isolation exercises; focus on pushing the weight on big compounds.</li></ul><p><a href="/exercise-library#science">Read the full science and browse every exercise and variation in the Exercise Library</a>.</p></div>' +
      '<div class="tt-g"><p class="label">Progressive overload</p><h3>' + esc(o[0]) + '</h3><p>' + esc(o[1]) + '</p>' +
      '<div class="tt-table"><table><thead><tr><th>Week</th><th>Example: rep range 8–12</th><th>What changed</th></tr></thead><tbody>' +
      '<tr><td>1</td><td>60 kg × 10, 9, 8</td><td>Baseline, 2 reps in the tank</td></tr>' +
      '<tr><td>2</td><td>60 kg × 11, 10, 9</td><td>+1 rep per set</td></tr>' +
      '<tr><td>3</td><td>60 kg × 12, 11, 10</td><td>Top set hits 12</td></tr>' +
      '<tr><td>4</td><td>60 kg × 12, 12, 12</td><td>Every set at the top: add weight</td></tr>' +
      '<tr><td>5</td><td>62.5 kg × 9, 8, 8</td><td>Heavier, back to the bottom of the range</td></tr>' +
      '</tbody></table></div>' +
      '<ul class="tt-list"><li><b>Track everything.</b> Use the log under each exercise. If you do not write it down, you are guessing.</li><li><b>Only add weight with good form.</b> A rep only counts if it matches your first rep in range and control.</li><li><b>Stalled for 3 sessions?</b> Check sleep, food and stress first. Then drop the weight 10%, rebuild, or swap to a variation of the exercise.</li><li><b>Deload every 5–8 weeks</b> (or when everything feels heavy): keep the same exercises and weights but halve the sets for one week. You will come back stronger.</li></ul></div>' +
      '<div class="tt-g"><p class="label">Effort</p><h3>Reps in reserve (RIR) and RPE</h3><p>Muscle and strength come from hard sets. "Reps in reserve" means how many more reps you could have done with good form. 2 RIR means you stopped with two clean reps left. RPE is the same idea on a 1–10 scale: RPE 8 = 2 reps left, RPE 9 = 1 left, RPE 10 = nothing left.</p><ul class="tt-list"><li>Most of your sets should end 0–3 reps from failure. Easy sets do not build much.</li><li>Take isolation exercises (curls, raises, flies) closer to failure. Keep heavy compounds (squats, deadlifts, bench) 1–3 reps away so form stays safe.</li><li>Beginners are bad at judging RIR. Film a set occasionally; the bar speed slowing right down means you are near failure.</li></ul></div>' +
      '<div class="tt-g"><p class="label">Warm-up</p><h3>Before every session (8–10 minutes)</h3><ol class="tt-list"><li>3–5 minutes of easy cardio (bike, incline walk, rower) to raise your body temperature.</li><li>Dynamic mobility for the day\'s joints: leg swings, hip openers and bodyweight squats on lower days; arm circles, band pull-aparts and push-ups on upper days.</li><li>Ramp-up sets on your first exercise: empty bar or light weight × 10, ~50% × 5, ~70% × 3, ~85% × 1–2, then start your working sets.</li><li>Later exercises only need one lighter feeder set.</li></ol></div>' +
      '<div class="tt-g"><p class="label">Form</p><h3>The rules that apply to every lift</h3><ul class="tt-list"><li><b>Brace.</b> Breathe into your belly, then tighten your abs as if about to be punched. Hold it through the hardest part of the rep.</li><li><b>Full range of motion.</b> Lower until you feel a deep stretch in the target muscle. The stretched position builds the most muscle.</li><li><b>Control the lowering.</b> Take 2–3 seconds on the way down, then lift with intent. Never bounce or drop the weight.</li><li><b>Stable joints.</b> Feet planted, shoulder blades set, wrists stacked under the load.</li><li><b>Leave your ego at the door.</b> If you need to swing, shorten the range or bounce to finish a rep, the weight is too heavy.</li><li><b>Pain is a stop sign.</b> Muscle burn is fine. Sharp or joint pain is not. Stop, swap the exercise, and see a professional if it continues.</li></ul></div>' +
      '<div class="tt-g"><p class="label">Week one</p><h3>How to pick your starting weights</h3><p>Spend your first week finding your numbers rather than testing your limits. Pick a weight you think you could lift for about 3 more reps than the top of your range. If the set felt easy (4+ reps left), go up next set. If you could not reach the bottom of the range, go down. Write down what worked. Week two is your real start line.</p></div>' +
      '<div class="tt-g"><p class="label">Your split</p><h3>' + esc(sp.n) + '</h3><p>' + esc(sp.why) + '</p><div class="tt-pc"><div><h4>Pros</h4><ul class="tt-good">' + sp.pros.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ul></div><div><h4>Trade-offs</h4><ul class="tt-bad">' + sp.cons.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ul></div></div></div>' +
      '<div class="tt-g"><p class="label">' + (st.sex === 'female' ? 'Training as a woman' : 'Training as a man') + '</p><h3>' + (st.sex === 'female' ? 'Same principles, your priorities' : 'Same principles, built around you') + '</h3>' +
      (st.sex === 'female'
        ? '<p>Muscle grows the same way in women and men: hard sets, progressive overload, enough protein and enough sleep. Lifting heavy will not make you "bulky"; it builds the toned, strong shape most women are after. Your plan starts with a glutes and legs focus because that is what most women ask for, but you can switch to Balanced or Upper body any time.</p><ul class="tt-list"><li>Research suggests women often recover faster between sets, so your rest times on accessories are slightly shorter.</li><li>Upper-body strength usually progresses in smaller jumps. Microplates (0.5–1.25 kg) and the next dumbbell up are your friends.</li><li>Train through your cycle and adjust by feel. If a week feels harder, keep the weights and do fewer sets; consistency beats perfection.</li></ul>'
        : '<p>Muscle grows from hard sets taken close to failure, adding weight or reps over time, eating enough protein and sleeping well. Your plan uses a balanced focus so your chest, back, shoulders, arms and legs develop in proportion. Switch to Upper body if you want more shoulders and arms, or Glutes & legs if your legs are lagging.</p><ul class="tt-list"><li>Do not skip legs. A strong lower body drives your overall strength and athleticism.</li><li>Prioritise the back and side delts as much as the chest; that is what builds a wide, V-tapered frame.</li><li>Ego lifting is the number one cause of injury. Earn every kilo with clean reps.</li></ul>') + '</div>' +
      nutritionGuide() +
      '<div class="tt-g"><p class="label">Recovery</p><h3>You grow when you rest</h3><ul class="tt-list"><li><b>Sleep 7–9 hours.</b> Nothing you take or do comes close to the effect of good sleep on recovery and strength.</li><li><b>Protein: about 1.6–2.2 g per kg of bodyweight a day</b>, spread over 3–5 meals. Get your exact targets in <a href="/nutrition-tool">Close The Market Nutrition</a>.</li><li><b>Steps:</b> aim for 7,000–10,000 a day for heart health and fat loss without hurting your recovery.</li><li><b>Consistency over intensity.</b> The plan you follow for a year beats the perfect plan you quit after a month.</li></ul></div>' +
      '<div class="tt-g tt-disc"><p>This is general training guidance based on my own experience and established strength and conditioning principles. It is not medical advice. If you have an injury, a medical condition, are pregnant, or are new to exercise and unsure, speak to your GP or a qualified coach or physiotherapist before you start. Stop any exercise that causes sharp pain.</p></div>';
  }

  /* ---------- events ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-set]');
    if (b) {
      var k = b.getAttribute('data-set'), v = b.getAttribute('data-val');
      st[k] = (k === 'days' || k === 'mins') ? +v : v;
      if (k === 'days' || k === 'goal' || k === 'exp') st.split = '';
      if (k === 'sex') st.emphasis = '';
      if (k === 'days' || k === 'split') st.swaps = {};
      save(); renderForm(); if (st.built) renderPlan();
      return;
    }
    if (e.target.closest('#tt-build')) {
      st.built = true; save(); renderForm(); renderPlan();
      $('#tt-out').hidden = false;
      var t = $('#tt-plan'); if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }
    if (e.target.closest('#tt-expand')) { var open = !$$('.tt-ex')[0].open; $$('.tt-ex').forEach(function (d) { d.open = open; }); e.target.textContent = open ? 'Close every exercise' : 'Open every exercise'; return; }
    if (e.target.closest('#tt-print')) { $$('.tt-ex').forEach(function (d) { d.open = true; }); window.print(); return; }
    if (e.target.closest('#tt-reset')) { st.swaps = {}; save(); renderPlan(); return; }
    var ls = e.target.closest('[data-logsave]');
    if (ls) {
      var id = ls.getAttribute('data-logsave');
      var w = parseFloat($('[data-lw="' + id + '"]').value);
      var r = ($('[data-lr="' + id + '"]').value || '').split(/[,\s/]+/).map(function (x) { return parseInt(x, 10); }).filter(function (x) { return x > 0; });
      var out = $('#next-' + id);
      if (!(w >= 0) || !r.length) { out.innerHTML = '<b>Enter the weight and the reps for each set</b>, e.g. 10, 9, 8.'; return; }
      var entry = { w: w, r: r, date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) };
      (st.logs[id] = st.logs[id] || []).push(entry); if (st.logs[id].length > 30) st.logs[id].shift();
      save();
      out.innerHTML = nextAdvice(id, entry, { sets: +ls.getAttribute('data-sets'), reps: ls.getAttribute('data-reps') });
      ls.textContent = 'Saved'; setTimeout(function () { ls.textContent = 'Save'; }, 1500);
    }
  });
  document.addEventListener('change', function (e) {
    var s = e.target.closest('[data-swap]');
    if (s) {
      var slot = s.getAttribute('data-swap'), plan = currentPlan(), base = null;
      plan.days.forEach(function (d) { d.items.forEach(function (it) { if (it.slot === slot) base = it.base; }); });
      if (s.value === base) delete st.swaps[slot]; else st.swaps[slot] = s.value;
      save(); renderPlan();
      var el = document.getElementById('ex-' + slot.replace(':', '-')); if (el) { el.open = true; el.scrollIntoView({ block: 'center' }); }
    }
  });

  function init() {
    if (!$('#tt-form')) return;
    renderForm();
    if (st.built) { $('#tt-out').hidden = false; renderPlan(); }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

